# Homologação Analyzer Local V2.3.0

- [ ] START_SCOUT_ANALYZER_V2.cmd abre a interface no Windows.
- [ ] Aba Ponte Scout V74 mostra token e status ativo.
- [ ] Scout V74.3 conecta em 127.0.0.1:8765 com token.
- [ ] Tarefa enviada pelo Scout aparece na fila do Analyzer.
- [ ] Tarefa atleta/highlights carrega contexto corretamente.
- [ ] Tarefa equipe/jogo carrega roster quando o jogo possui elenco.
- [ ] Análise cria `scout_analysis_v2.json`, `scout_analysis_v3.json` e PDF preliminar.
- [ ] Resultado concluído é entregue pela ponte.
- [ ] Scout recebe V3 e exige revisão humana.
- [ ] Continuar análise após erro mantém chunks e job_id.
- [ ] Saúde da análise reflete chunks/evidências/limitações.
- [ ] Fluxo manual JSON continua funcionando.
