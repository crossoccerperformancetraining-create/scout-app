# Scout Video Analyzer Local V2.3.0

- Ponte HTTP local em `127.0.0.1:8765`, token obrigatório.
- Fila de tarefas recebidas do Scout Intelligence V74.3.
- Status persistentes: queued, loaded, running, completed, error e acknowledged.
- Entrega automática do `scout.analysis.v3` quando a análise termina.
- Aba **Saúde da análise** com fonte, chunks, evidências, confiança de identificação, limitações, V3 e PDF.
- Retomada de projeto preserva o `job_id` e volta a alimentar a ponte ao concluir.
- Em modo Equipe, aceita elenco vindo do Scout e pode registrar atleta observado por evidência somente quando houver confiança visual suficiente.
- V3 preserva `observed_player` nas evidências coletivas quando existir.
- JSON manual continua suportado integralmente.
