# Integração Audit Scout - contrato `scout.analysis.v3`

## Objetivo

O `scout.analysis.v3` é o contrato neutro entre o motor de vídeo e qualquer interface: Analyzer Local, Audit Scout web, aplicativo móvel ou ferramenta de consultoria.

A regra central é: **evidência observada, interpretação da IA, opinião humana e decisão final são camadas diferentes**.

## Camadas do contrato

1. `evidence`: fatos/evidências localizadas no vídeo, com timestamp, resultado e confiança separada.
2. `ai_assessment`: síntese sugerida pela IA; nunca é a decisão oficial.
3. `human_assessment`: opinião do scout/analista/treinador.
4. `review.decisions`: confirmações, ajustes e rejeições item a item.
5. `final_assessment`: conclusão oficial após revisão humana.
6. `audit`: origem, modelo, estratégia e princípio de autoridade humana.
7. `report`: metadados para geração do PDF.

## Confianças separadas

Cada evidência possui:

- `identification`: certeza de que o atleta/equipe analisado é o alvo correto;
- `action`: certeza sobre o que aconteceu no lance;
- `context`: certeza sobre equipe, adversário, competição/camisa observados;
- `overall`: confiança conservadora usada para triagem.

Isso evita dizer que uma ação é incerta apenas porque a equipe não foi reconhecida, ou dizer que o atleta foi reconhecido com alta certeza apenas porque a ação foi clara.

## Fluxo sugerido no Audit Scout

### Importação

`Vídeos > Análise IA > Importar resultado (.json)`

O importador deve aceitar `schema_version = scout.analysis.v3` e criar um registro de revisão sem confirmar nada automaticamente.

### Tela de revisão

Três colunas/blocos são recomendados:

- **Evidência de vídeo**: timestamp, ação, resultado, confidências e contexto observado.
- **Leitura da IA**: ponto forte/desenvolvimento/comportamento tático sugerido.
- **Decisão humana**: `Confirmar`, `Ajustar`, `Rejeitar`, com observação opcional.

### Duas opiniões

O Audit Scout deve manter simultaneamente:

- `ai_assessment`: opinião assistida por IA;
- `human_assessment`: opinião profissional.

A nota/decisão oficial deve ser registrada em `final_assessment`, nunca sobrescrevendo as duas fontes originais.

### Exemplo de decisão de revisão

```json
{
  "decision_id": "REV-0001",
  "target_type": "evidence",
  "target_id": "EVT-0004",
  "decision": "confirmed",
  "human_note": "Desarme 1v1 confirmado pelo analista.",
  "reviewed_by": "user-id",
  "reviewed_at": "2026-09-04T12:00:00Z"
}
```

Valores sugeridos para `decision`: `confirmed`, `adjusted`, `rejected`.

## Regra de pontos a desenvolver

Um item só pode permanecer em `development_points`/`collective_vulnerabilities` quando estiver ligado a pelo menos uma evidência de vídeo.

Se não houver evidência, o item deve ficar em `non_evaluable_items`. Isso evita transformar falta de informação em deficiência do atleta/equipe.

## Melhores momentos

Para `material.type = highlights`:

- nota numérica automática fica `null`;
- consistência, frequência real e ausência de erros não podem ser inferidas;
- o relatório deve exibir a advertência de amostra selecionada;
- equipe/camisa/adversário/competição podem variar entre lances.

## Relatório PDF

O Analyzer V2.3.0 gera `scout_report_draft.pdf` como **rascunho**. Ele mostra IA, evidências e espaço/status da avaliação humana.

No Audit Scout, o PDF oficial deve ser gerado somente quando:

1. `review.status` estiver revisado/aprovado;
2. `human_assessment` estiver preenchido quando exigido pelo fluxo;
3. `final_assessment.status` estiver aprovado.

O relatório oficial pode apresentar:

- resumo executivo;
- opinião do scout/analista;
- leitura assistida por IA;
- convergências e divergências;
- pontos fortes confirmados;
- pontos a desenvolver confirmados;
- comportamento tático;
- evidências com timestamps;
- itens não avaliáveis;
- nota final/recomendação profissional;
- trilha de auditoria.

## Compatibilidade

O Analyzer continua salvando `scout_analysis_v2.json` para rastreabilidade/compatibilidade local, mas a integração nova deve usar `scout_analysis_v3.json`.

O arquivo `scout_analysis_v3.schema.json` acompanha o pacote e pode ser usado no backend/web para validar importações.


## Ponte automática local V2.3

A ponte local transporta somente tarefa/status/resultado. Ela não confirma identidade, não aplica nota e não substitui a revisão humana. Use o JSON manual quando a ponte não estiver disponível.
