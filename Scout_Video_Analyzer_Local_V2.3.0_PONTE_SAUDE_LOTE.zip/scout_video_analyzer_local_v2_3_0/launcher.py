from __future__ import annotations

import os
import traceback
from datetime import datetime
from pathlib import Path

APP_TITLE = "Scout Video Analyzer Local V2.3.0"


def _log_path() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "ScoutVideoAnalyzerLocalV2" / "logs"
    base.mkdir(parents=True, exist_ok=True)
    return base / "startup.log"


def _show_error(message: str) -> None:
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, APP_TITLE, 0x10)
    except Exception:
        pass


def main() -> int:
    log = _log_path()
    try:
        from app import ScoutAnalyzerV2
        app = ScoutAnalyzerV2()
        app.mainloop()
        return 0
    except Exception:
        details = traceback.format_exc()
        try:
            with log.open("a", encoding="utf-8") as f:
                f.write("\n" + "=" * 72 + "\n")
                f.write(datetime.now().isoformat(timespec="seconds") + "\n")
                f.write(details)
        except Exception:
            pass
        _show_error(
            "O Scout Video Analyzer V2 não conseguiu abrir.\n\n"
            "Foi criado um diagnóstico em:\n"
            f"{log}\n\n"
            "Abra DIAGNOSTICO_SCOUT.cmd para ver os detalhes."
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
