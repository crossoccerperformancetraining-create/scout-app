from __future__ import annotations

import tempfile
from pathlib import Path

from audit_contract import build_analysis_v3, build_observed_context
from pipeline import (
    create_project,
    _build_windows,
    _normalize_chunk,
    _merge_chunks,
    _build_final_json,
    _empty_synthesis,
    _normalize_synthesis,
)
from prompts import chunk_prompt, synthesis_prompt
from report_pdf import generate_report_pdf


def full_match_context():
    return {
        "target_type": "athlete",
        "material_type": "full_match",
        "athlete_name": "João Pedro",
        "team": "CSE",
        "teams_context": ["CSE"],
        "position": "Zagueiro",
        "shirt_number": "3",
        "opponent": "Murici",
        "opponents_context": ["Murici"],
        "competition": "Copa Alagoas",
        "competitions_context": ["Copa Alagoas"],
        "match_date": None,
        "period": None,
        "notes": None,
        "model_game": "",
        "duration_minutes": 95,
        "source": {"type": "youtube", "url": "https://www.youtube.com/watch?v=example"},
        "identification_strategy": "match_context_and_visual_continuity",
    }


def athlete_highlights_context():
    return {
        "target_type": "athlete",
        "material_type": "highlights",
        "athlete_name": "João Pedro",
        "team": None,
        "teams_context": ["Retrô", "CSA", "CSE"],
        "position": "Zagueiro",
        "shirt_number": None,
        "opponent": None,
        "opponents_context": [],
        "competition": None,
        "competitions_context": ["Copa do Nordeste", "Copa Alagoas"],
        "match_date": None,
        "period": "2023-2026",
        "notes": "Compilado de carreira",
        "model_game": "",
        "duration_minutes": None,
        "source": {"type": "youtube", "url": "https://www.youtube.com/watch?v=highlights"},
        "identification_strategy": "visual_graphics_preferred_when_present",
    }


context = full_match_context()
windows = _build_windows(context, 95 * 60)
assert len(windows) >= 10
raw = {
    "athlete_seen": True,
    "identification_confidence": 0.93,
    "observed_athlete_name": "João Pedro Rocha",
    "observed_athlete_aliases": ["João Rocha"],
    "identification_cues": ["camisa 3", "grafismo"],
    "events": [
        {
            "offset_seconds": 30,
            "phase": "defensiva",
            "category": "duelo_aereo",
            "action": "disputa aérea defensiva",
            "outcome": "positivo",
            "result_code": "won",
            "result_label": "duelo aéreo vencido",
            "description": "antecipa o atacante e afasta",
            "identification_confidence": 0.92,
            "action_confidence": 0.88,
            "context_confidence": 0.76,
            "observed_team": "CSE",
            "observed_team_confidence": 0.9,
            "observed_shirt_number": 3,
            "observed_shirt_number_confidence": 0.75,
        }
    ],
    "limitations": [],
}
ch = _normalize_chunk(raw, context, 1, 0, 480)
assert ch["events"][0]["observed_shirt_number"] == "3"
assert ch["events"][0]["result"]["code"] == "won"
assert ch["events"][0]["confidence_breakdown"]["action"] == 0.88
assert ch["events"][0]["confidence_breakdown"]["identification"] == 0.92

events, limitations, ident = _merge_chunks([ch], context)
assert ident["observed_name"] == "João Pedro Rocha"
assert "João Rocha" in ident["observed_aliases"]
observed = build_observed_context(events)
assert observed["teams"][0]["value"] == "CSE"

# No evidence => development point must become non-evaluable.
raw_synthesis = {
    "strengths": [{"title": "Jogo aéreo", "analysis": "Vence duelo", "confidence": 0.8, "evidence_event_ids": ["EVT-0001"]}],
    "development_points": [{"title": "Pressão contínua", "analysis": "Não foi possível observar", "confidence": 0.6, "evidence_event_ids": []}],
    "tactical_behavior": {"with_ball": [], "without_ball": [], "transitions": [], "positional_discipline": []},
    "model_game_comparison": [],
    "non_evaluable_items": [],
    "suggested_rating": {"score_0_to_10": 8.0, "confidence": 0.7, "rationale": "teste", "human_review_required": True},
    "warnings": [],
}
normalized = _normalize_synthesis(raw_synthesis, context, {"EVT-0001"})
assert len(normalized["development_points"]) == 0
assert any("Pressão contínua" in x for x in normalized["non_evaluable_items"])
assert normalized["strengths"][0]["evidence_level"] == "single"

final = _build_final_json(context, "gemini-3.7-flash", windows, events, limitations, ident, observed, normalized, None)
assert final["schema_version"] == "scout.video_analysis.v2"
assert final["athlete"]["name_informed"] == "João Pedro"
assert final["athlete"]["name_observed"] == "João Pedro Rocha"
assert final["observed_context"]["teams"][0]["value"] == "CSE"

v3 = build_analysis_v3(final)
assert v3["schema_version"] == "scout.analysis.v3"
assert v3["subject"]["athlete"]["name_informed"] == "João Pedro"
assert v3["subject"]["athlete"]["name_observed"] == "João Pedro Rocha"
assert v3["evidence"][0]["confidence"]["identification"] == 0.92
assert v3["review"]["status"] == "pending_human_review"
assert v3["human_assessment"]["status"] == "not_started"

# Highlights: rating must be null even if model tries to score.
high = athlete_highlights_context()
assert _build_windows(high, None) == [{"start_s": None, "end_s": None}]
prompt = chunk_prompt(high, 0, None)
assert "observed_athlete_name" in prompt
assert "action_confidence" in prompt
assert "result_code" in prompt
assert "EQUIPES, UNIFORMES e NÚMEROS DE CAMISA DIFERENTES" in prompt
assert "ponto a desenvolver" in synthesis_prompt(high, events, limitations)

high_syn = _normalize_synthesis(raw_synthesis, high, {"EVT-0001"})
assert high_syn["suggested_rating"]["score_0_to_10"] is None

with tempfile.TemporaryDirectory() as td:
    project = create_project(td, high)
    assert (project / "manifest.json").exists()
    pdf = Path(td) / "test_report.pdf"
    generate_report_pdf(v3, pdf)
    assert pdf.exists() and pdf.stat().st_size > 2000


# Team batch: individual attribution is optional and preserved only when returned with confidence.
team_ctx = {
    "target_type": "team", "material_type": "full_match", "athlete_name": None,
    "team": "ECUS Suzano", "teams_context": ["ECUS Suzano"], "position": None, "shirt_number": None,
    "opponent": "Adversário", "opponents_context": ["Adversário"], "competition": "Teste",
    "competitions_context": ["Teste"], "match_date": None, "period": None, "notes": None,
    "model_game": "", "duration_minutes": 90, "source": {"type":"youtube","url":"https://youtu.be/team"},
    "identification_strategy": "match_context_and_visual_continuity",
    "team_roster": [{"player_id":"P1","name":"João","position":"VOL"}],
}
team_raw = {"team_seen": True, "team_identification_confidence": .9, "events":[{
    "offset_seconds": 10, "phase":"transicao_defensiva", "category":"pressao", "pattern":"pressão pós-perda",
    "description":"Equipe reage à perda", "action_confidence":.8, "identification_confidence":.9,
    "observed_player_name":"João", "observed_player_id":"P1", "observed_player_position":"VOL", "observed_player_confidence":.78
}], "limitations":[]}
team_chunk = _normalize_chunk(team_raw, team_ctx, 1, 0, 480)
assert team_chunk["events"][0]["observed_player_id"] == "P1"
team_events, team_lim, team_ident = _merge_chunks([team_chunk], team_ctx)
team_final = _build_final_json(team_ctx, "gemini-3.7-flash", [{"start_s":0,"end_s":480}], team_events, team_lim, team_ident, build_observed_context(team_events), _empty_synthesis(team_ctx), None)
team_v3 = build_analysis_v3(team_final)
assert team_v3["evidence"][0]["observed_player"]["player_id"] == "P1"

print("TESTE_ESTRUTURA V2.3.0: OK")
