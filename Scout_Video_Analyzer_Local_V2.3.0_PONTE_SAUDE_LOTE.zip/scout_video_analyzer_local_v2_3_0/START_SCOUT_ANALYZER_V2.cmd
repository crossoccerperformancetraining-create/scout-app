@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Scout Video Analyzer Local V2.3.0

set "SCOUT_HOME=%LOCALAPPDATA%\ScoutVideoAnalyzerLocalV2"
set "VENV=%SCOUT_HOME%\venv"
set "LOGDIR=%SCOUT_HOME%\logs"
set "STARTLOG=%LOGDIR%\start_v230.log"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1

echo ============================================================>>"%STARTLOG%"
echo [%date% %time%] START V2.3.0>>"%STARTLOG%"
echo Pasta: %CD%>>"%STARTLOG%"

echo Preparando Scout Video Analyzer V2.3.0...
call "%~dp0_PREPARAR_AMBIENTE.cmd"
if errorlevel 1 exit /b %errorlevel%

if not exist "%VENV%\Scripts\python.exe" (
  echo O ambiente Python nao foi criado corretamente.>>"%STARTLOG%"
  echo O ambiente Python nao foi criado corretamente.
  echo Abra DIAGNOSTICO_SCOUT.cmd.
  pause
  exit /b 1
)

rem Smoke test antes de esconder a janela. Assim erros de importacao ficam diagnosticaveis.
echo Verificando componentes...
"%VENV%\Scripts\python.exe" -c "import tkinter, keyring; from google import genai; import reportlab; import app, pipeline, prompts, gemini_client, audit_contract, report_pdf, local_bridge; print('smoke ok')" >>"%STARTLOG%" 2>&1
if errorlevel 1 (
  echo Falha na verificacao de componentes. Veja %STARTLOG%
  echo Abra DIAGNOSTICO_SCOUT.cmd.
  pause
  exit /b 1
)

echo Abrindo Scout Video Analyzer V2.3.0...
if exist "%VENV%\Scripts\pythonw.exe" (
  start "Scout Video Analyzer V2.3.0" "%VENV%\Scripts\pythonw.exe" "%~dp0launcher.py"
) else (
  start "Scout Video Analyzer V2.3.0" "%VENV%\Scripts\python.exe" "%~dp0launcher.py"
)
if errorlevel 1 (
  echo Nao foi possivel iniciar a janela. Abra DIAGNOSTICO_SCOUT.cmd.
  pause
  exit /b 1
)
exit /b 0
