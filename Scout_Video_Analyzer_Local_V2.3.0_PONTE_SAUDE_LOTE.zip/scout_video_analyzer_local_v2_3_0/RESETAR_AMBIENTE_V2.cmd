@echo off
setlocal EnableExtensions
set "SCOUT_HOME=%LOCALAPPDATA%\ScoutVideoAnalyzerLocalV2"
echo Isto apaga apenas o ambiente Python/cache da V2. Projetos salvos em outras pastas nao serao apagados.
pause
if exist "%SCOUT_HOME%\venv" rmdir /s /q "%SCOUT_HOME%\venv"
del /q "%SCOUT_HOME%\deps_v*.ok" >nul 2>&1
echo Ambiente resetado. Abra START_SCOUT_ANALYZER_V2.cmd.
pause
