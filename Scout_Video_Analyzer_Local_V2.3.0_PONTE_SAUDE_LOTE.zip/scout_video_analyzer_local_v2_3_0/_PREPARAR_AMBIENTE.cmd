@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "APPVER=2.3.0"
set "SCOUT_HOME=%LOCALAPPDATA%\ScoutVideoAnalyzerLocalV2"
set "VENV=%SCOUT_HOME%\venv"
set "LOGDIR=%SCOUT_HOME%\logs"
set "LOG=%LOGDIR%\setup.log"
set "MARKER=%SCOUT_HOME%\deps_v230.ok"

if not exist "%SCOUT_HOME%" mkdir "%SCOUT_HOME%" >nul 2>&1
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1

echo ============================================================>>"%LOG%"
echo [%date% %time%] Preparando ambiente V%APPVER%>>"%LOG%"
echo Pasta do programa: %CD%>>"%LOG%"

set "PYEXE="
where py >nul 2>&1
if not errorlevel 1 (
  py -3.14 -c "import sys" >nul 2>&1 && set "PYEXE=py -3.14"
  if not defined PYEXE py -3.13 -c "import sys" >nul 2>&1 && set "PYEXE=py -3.13"
  if not defined PYEXE py -3.12 -c "import sys" >nul 2>&1 && set "PYEXE=py -3.12"
  if not defined PYEXE py -3.11 -c "import sys" >nul 2>&1 && set "PYEXE=py -3.11"
)
if not defined PYEXE (
  where python >nul 2>&1 && set "PYEXE=python"
)
if not defined PYEXE goto :no_python

rem Se o ambiente sumiu, remova marcadores antigos para forcar reinstalacao.
if not exist "%VENV%\Scripts\python.exe" (
  echo Criando ambiente Python local da V2...
  del /q "%SCOUT_HOME%\deps_v*.ok" >nul 2>&1
  if exist "%VENV%" rmdir /s /q "%VENV%" >nul 2>&1
  %PYEXE% -m venv "%VENV%" >>"%LOG%" 2>&1
  if errorlevel 1 goto :fail
)

if not exist "%VENV%\Scripts\python.exe" goto :fail

rem Mesmo com marcador, valide o ambiente. Se estiver incompleto, reinstale.
set "NEED_INSTALL=0"
if not exist "%MARKER%" set "NEED_INSTALL=1"
if "%NEED_INSTALL%"=="0" (
  "%VENV%\Scripts\python.exe" -c "import tkinter, keyring; from google import genai; import reportlab; import app, pipeline, prompts, gemini_client, audit_contract, report_pdf, local_bridge" >nul 2>&1
  if errorlevel 1 set "NEED_INSTALL=1"
)

if "%NEED_INSTALL%"=="1" (
  echo Instalando/atualizando componentes da V2.3.0...
  "%VENV%\Scripts\python.exe" -m pip install --upgrade pip >>"%LOG%" 2>&1
  if errorlevel 1 goto :fail
  "%VENV%\Scripts\python.exe" -m pip install --upgrade --no-cache-dir -r "%~dp0requirements.txt" >>"%LOG%" 2>&1
  if errorlevel 1 goto :fail
  "%VENV%\Scripts\python.exe" -c "import tkinter, keyring; from google import genai; import reportlab; import app, pipeline, prompts, gemini_client, audit_contract, report_pdf, local_bridge; print('V2.3.0 dependencias ok')" >>"%LOG%" 2>&1
  if errorlevel 1 goto :fail
  del /q "%SCOUT_HOME%\deps_v*.ok" >nul 2>&1
  >"%MARKER%" echo V2.3.0
)

endlocal & exit /b 0

:no_python
echo.
echo Python 3 nao foi encontrado neste Windows.
where winget >nul 2>&1
if not errorlevel 1 (
  echo Pressione qualquer tecla para instalar Python 3.13 pelo Windows Package Manager ou feche a janela para cancelar.
  pause >nul
  winget install --id Python.Python.3.13 -e --scope user --accept-package-agreements --accept-source-agreements >>"%LOG%" 2>&1
  echo Depois da instalacao, abra novamente START_SCOUT_ANALYZER_V2.cmd.
  pause
  endlocal & exit /b 2
)
echo Instale Python 3.11 ou superior pelo site oficial python.org e marque Add Python to PATH.
pause
endlocal & exit /b 1

:fail
echo.
echo Nao foi possivel preparar o Scout Video Analyzer V2.3.0.
echo Diagnostico: %LOG%
echo Abra DIAGNOSTICO_SCOUT.cmd.
pause
endlocal & exit /b 1
