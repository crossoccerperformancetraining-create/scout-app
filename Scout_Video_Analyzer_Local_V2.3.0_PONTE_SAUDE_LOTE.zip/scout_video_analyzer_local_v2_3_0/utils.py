from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def seconds_to_hms(value: float | int) -> str:
    total = max(0, int(round(float(value))))
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def parse_duration_seconds(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    # Some SDK versions may expose a timedelta-like object.
    total_seconds = getattr(value, "total_seconds", None)
    if callable(total_seconds):
        try:
            return float(total_seconds())
        except Exception:
            pass
    text = str(value).strip()
    if not text:
        return None
    # Google Duration format, e.g. "123.45s"
    m = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)s", text)
    if m:
        return float(m.group(1))
    # HH:MM:SS / MM:SS
    parts = text.split(":")
    if all(p.replace(".", "", 1).isdigit() for p in parts):
        nums = [float(p) for p in parts]
        if len(nums) == 3:
            return nums[0] * 3600 + nums[1] * 60 + nums[2]
        if len(nums) == 2:
            return nums[0] * 60 + nums[1]
    return None


def safe_json_loads(text: str) -> Any:
    raw = (text or "").strip()
    if not raw:
        raise ValueError("Resposta vazia do Gemini.")
    # Strip common markdown fences defensively.
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
        raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # Recover first JSON object/array if the model accidentally added text.
        starts = [i for i in (raw.find("{"), raw.find("[")) if i >= 0]
        if not starts:
            raise
        start = min(starts)
        for end in range(len(raw), start, -1):
            snippet = raw[start:end].strip()
            if not snippet or snippet[-1] not in "}]":
                continue
            try:
                return json.loads(snippet)
            except Exception:
                continue
        raise


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def slugify(value: str, fallback: str = "analise") -> str:
    text = re.sub(r"[^A-Za-z0-9_-]+", "_", (value or "").strip())
    text = re.sub(r"_+", "_", text).strip("_")
    return text[:60] or fallback
