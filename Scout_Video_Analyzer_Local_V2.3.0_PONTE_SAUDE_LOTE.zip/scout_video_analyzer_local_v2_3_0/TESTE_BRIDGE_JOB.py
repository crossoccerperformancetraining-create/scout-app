from bridge_job import parse_scout_job

job={
 "schema_version":"scout.analyzer.job.v1",
 "job_id":"JOB-TESTE",
 "analysis_target":"athlete",
 "material_type":"highlights",
 "subject":{"type":"athlete","athlete":{"player_id":"p1","name_informed":"João","position":"ZAG","team_informed":"CSE"}},
 "material":{"type":"highlights","source":{"type":"youtube","reference":"https://www.youtube.com/watch?v=abc"}},
 "context":{"informed":{"team":"CSE","opponent":"ASA","competition":"Teste","notes":"observação"}},
 "output_contract":{"schema_version":"scout.analysis.v3","human_review_required":True},
}
p=parse_scout_job(job)
assert p["target_type"]=="athlete"
assert p["material_type"]=="highlights"
assert p["fields"]["athlete_name"]=="João"
assert p["fields"]["position"]=="ZAG"
assert p["source_type"]=="youtube"
assert p["integration"]["job_id"]=="JOB-TESTE"
print("TESTE_BRIDGE_JOB V2.3.0: OK")
