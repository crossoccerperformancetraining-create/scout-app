from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from typing import Any

APP_VERSION = "Scout Video Analyzer Local V2.3.0"


def _clamp(value: Any) -> float:
    try:
        return round(max(0.0, min(1.0, float(value))), 3)
    except Exception:
        return 0.0


def _clean(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None


def build_observed_context(events: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    fields = {
        "teams": ("observed_team", "observed_team_confidence"),
        "opponents": ("observed_opponent", "observed_opponent_confidence"),
        "competitions": ("observed_competition", "observed_competition_confidence"),
        "shirt_numbers": ("observed_shirt_number", "observed_shirt_number_confidence"),
    }
    output: dict[str, list[dict[str, Any]]] = {}
    for out_key, (value_key, confidence_key) in fields.items():
        bucket: dict[str, dict[str, Any]] = defaultdict(lambda: {"mentions": 0, "confidences": []})
        for event in events:
            value = _clean(event.get(value_key))
            if not value:
                continue
            row = bucket[value]
            row["mentions"] += 1
            confidence = event.get(confidence_key)
            if confidence is None:
                confidence = (event.get("confidence_breakdown") or {}).get("context")
            if confidence is not None:
                row["confidences"].append(_clamp(confidence))
        rows = []
        for value, meta in bucket.items():
            confs = meta["confidences"]
            rows.append({
                "value": value,
                "mentions": int(meta["mentions"]),
                "confidence_mean": round(sum(confs) / len(confs), 3) if confs else 0.0,
            })
        rows.sort(key=lambda x: (-x["mentions"], -x["confidence_mean"], x["value"].lower()))
        output[out_key] = rows
    return output


def _evidence_v3(event: dict[str, Any], target_type: str) -> dict[str, Any]:
    confidence = event.get("confidence_breakdown") if isinstance(event.get("confidence_breakdown"), dict) else {}
    identification = _clamp(confidence.get("identification", event.get("confidence", 0.0)))
    action = _clamp(confidence.get("action", event.get("confidence", 0.0)))
    context = _clamp(confidence.get("context", event.get("context_confidence", 0.0)))
    overall = _clamp(confidence.get("overall", min(identification, action) if target_type == "athlete" else action))

    observed = {}
    for key in ("team", "shirt_number", "opponent", "competition"):
        value = _clean(event.get(f"observed_{key}"))
        if value:
            observed[key] = {
                "value": value,
                "confidence": _clamp(event.get(f"observed_{key}_confidence", context)),
            }

    if isinstance(event.get("result"), dict):
        result = event.get("result")
    else:
        legacy = str(event.get("outcome") or "inconclusivo").strip().lower()
        legacy_map = {
            "positivo": ("successful", "ação bem-sucedida"),
            "negativo": ("unsuccessful", "ação malsucedida"),
            "neutro": ("neutral", "resultado neutro"),
            "inconclusivo": ("inconclusive", "resultado inconclusivo"),
        }
        default_code, default_label = legacy_map.get(legacy, ("inconclusive", "resultado inconclusivo"))
        result = {
            "code": event.get("result_code") or default_code,
            "label": event.get("result_label") or default_label,
        }

    payload = {
        "evidence_id": event.get("event_id"),
        "source_chunk": event.get("source_chunk"),
        "video_time_seconds": event.get("video_time_seconds"),
        "video_timestamp": event.get("video_timestamp"),
        "phase": event.get("phase"),
        "category": event.get("category"),
        "description": event.get("description"),
        "tactical_note": event.get("tactical_note"),
        "result": {
            "code": _clean(result.get("code")) or "inconclusive",
            "label": _clean(result.get("label")) or "inconclusivo",
        },
        "confidence": {
            "identification": identification,
            "action": action,
            "context": context,
            "overall": overall,
        },
        "observed_context": observed,
        "identification_cues": list(event.get("identification_cues") or []),
    }
    if target_type == "athlete":
        payload["action"] = event.get("action")
    else:
        payload["pattern"] = event.get("pattern")
        player_name = _clean(event.get("observed_player_name"))
        player_id = _clean(event.get("observed_player_id"))
        player_position = _clean(event.get("observed_player_position"))
        if player_name or player_id:
            payload["observed_player"] = {
                "name": player_name or None,
                "player_id": player_id or None,
                "position": player_position or None,
                "confidence": _clamp(event.get("observed_player_confidence", identification)),
            }
    return payload



def _sanitize_ai_assessment(ai: dict[str, Any], material_type: str, target_type: str) -> dict[str, Any]:
    data = deepcopy(ai) if isinstance(ai, dict) else {}
    non_eval = list(data.get("non_evaluable_items") or [])

    def filter_items(key: str) -> None:
        value = data.get(key)
        if not isinstance(value, list):
            return
        kept = []
        for item in value:
            if not isinstance(item, dict):
                continue
            ids = [str(x) for x in (item.get("evidence_event_ids") or []) if str(x).strip()]
            if ids:
                item = deepcopy(item)
                item["evidence_level"] = "multiple" if len(ids) >= 2 else "single"
                kept.append(item)
            else:
                title = _clean(item.get("title") or item.get("criterion") or item.get("analysis")) or key
                msg = f"{title}: não há evidência de vídeo suficiente para tratar este item como conclusão observada."
                if msg not in non_eval:
                    non_eval.append(msg)
        data[key] = kept

    for key in ("strengths", "development_points", "collective_strengths", "collective_vulnerabilities", "key_patterns"):
        filter_items(key)

    for group_key in ("tactical_behavior", "phases"):
        group = data.get(group_key)
        if not isinstance(group, dict):
            continue
        new_group = {}
        for key, items in group.items():
            holder = {"items": items}
            # Inline equivalent of filter_items for nested sections.
            kept = []
            if isinstance(items, list):
                for item in items:
                    if not isinstance(item, dict):
                        continue
                    ids = [str(x) for x in (item.get("evidence_event_ids") or []) if str(x).strip()]
                    if ids:
                        item = deepcopy(item)
                        item["evidence_level"] = "multiple" if len(ids) >= 2 else "single"
                        kept.append(item)
                    else:
                        title = _clean(item.get("title") or item.get("analysis")) or f"{group_key}.{key}"
                        msg = f"{title}: não há evidência de vídeo suficiente para tratar este item como conclusão observada."
                        if msg not in non_eval:
                            non_eval.append(msg)
            new_group[key] = kept
        data[group_key] = new_group

    if material_type == "highlights" and isinstance(data.get("suggested_rating"), dict):
        data["suggested_rating"] = deepcopy(data["suggested_rating"])
        data["suggested_rating"]["score_0_to_10"] = None
        data["suggested_rating"]["human_review_required"] = True

    data["non_evaluable_items"] = non_eval
    return data

def build_analysis_v3(v2: dict[str, Any]) -> dict[str, Any]:
    """Convert the analyzer's V2 result into the platform-neutral Audit Scout contract."""
    target_type = v2.get("analysis_target") or "athlete"
    material_type = v2.get("material_type") or "unknown"
    identification = v2.get("identification") if isinstance(v2.get("identification"), dict) else {}
    events = v2.get("events") if isinstance(v2.get("events"), list) else []
    observed_context = v2.get("observed_context") if isinstance(v2.get("observed_context"), dict) else build_observed_context(events)

    informed_context: dict[str, Any]
    if material_type == "full_match":
        informed_context = deepcopy(v2.get("match") or {})
    else:
        informed_context = deepcopy(v2.get("compilation_context") or {})

    subject: dict[str, Any] = {"type": target_type}
    if target_type == "athlete":
        athlete = v2.get("athlete") if isinstance(v2.get("athlete"), dict) else {}
        subject["athlete"] = {
            "name_informed": athlete.get("name"),
            "name_observed": identification.get("observed_name"),
            "observed_aliases": identification.get("observed_aliases") or [],
            "position": athlete.get("position"),
            "shirt_number_informed": athlete.get("shirt_number"),
            "team_informed": athlete.get("team"),
        }
    else:
        team = v2.get("team") if isinstance(v2.get("team"), dict) else {}
        subject["team"] = {"name_informed": team.get("name")}

    ai_assessment = _sanitize_ai_assessment(v2.get("summary") or {}, material_type, target_type)
    ai_assessment["limitations"] = list(v2.get("limitations") or [])
    ai_assessment["sample_warning"] = v2.get("sample_warning")

    return {
        "schema_version": "scout.analysis.v3",
        "analysis_id": v2.get("analysis_id"),
        "created_at": v2.get("created_at"),
        "subject": subject,
        "material": {
            "type": material_type,
            "source": deepcopy(v2.get("source") or {}),
            "sample_warning": v2.get("sample_warning"),
        },
        "context": {
            "informed": informed_context,
            "observed": observed_context,
        },
        "identification": {
            "confidence_mean": _clamp(identification.get("confidence_mean", 0.0)),
            "identified_in_chunks": identification.get("identified_in_chunks", 0),
            "total_chunks": identification.get("total_chunks", 0),
            "visual_cues": list(identification.get("visual_cues") or []),
            "strategy": identification.get("strategy"),
            "observed_name": identification.get("observed_name"),
            "observed_aliases": list(identification.get("observed_aliases") or []),
        },
        "evidence": [_evidence_v3(e, target_type) for e in events],
        "ai_assessment": ai_assessment,
        "human_assessment": {
            "status": "not_started",
            "overall_rating_0_to_10": None,
            "strengths": [],
            "development_points": [],
            "tactical_notes": [],
            "recommendation": None,
            "notes": None,
        },
        "review": {
            "status": "pending_human_review",
            "human_review_required": True,
            "decisions": [],
        },
        "final_assessment": {
            "status": "pending_review",
            "overall_rating_0_to_10": None,
            "recommendation": None,
            "summary": None,
        },
        "audit": {
            "generated_by": APP_VERSION,
            "model": (v2.get("processing") or {}).get("model"),
            "processing_strategy": (v2.get("processing") or {}).get("strategy"),
            "source_schema": v2.get("schema_version"),
            "human_decision_is_authoritative": True,
            "integration": deepcopy(v2.get("integration") or {}),
        },
        "report": {
            "status": "draft_pending_human_review",
            "title": _default_report_title(v2),
            "pdf_filename": "scout_report_draft.pdf",
            "watermark": "RASCUNHO - REVISAO HUMANA PENDENTE",
        },
    }


def _default_report_title(v2: dict[str, Any]) -> str:
    if v2.get("analysis_target") == "athlete":
        athlete = v2.get("athlete") or {}
        name = athlete.get("name") or (v2.get("identification") or {}).get("observed_name") or "Atleta"
        position = athlete.get("position")
        return f"{name} - {position}" if position else str(name)
    team = v2.get("team") or {}
    return str(team.get("name") or "Equipe")
