from __future__ import annotations

import os
import queue
import shutil
import re
import threading
import traceback
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import keyring

from gemini_client import validate_api_key
from pipeline import create_project, run_project
from utils import read_json
from bridge_job import parse_scout_job
from local_bridge import (
    bridge_dirs, get_or_create_token, list_jobs, load_job, mark_state, next_queued_job,
    publish_result, read_state, start_bridge_server,
)

APP_TITLE = "Scout Video Analyzer Local V2.3.0"
KEYRING_SERVICE = "ScoutVideoAnalyzerLocal"
KEYRING_USER = "gemini_api_key"
LOG_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "ScoutVideoAnalyzerLocalV2" / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)


class ScoutAnalyzerV2(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1180x800")
        self.minsize(1050, 720)
        self.configure(bg="#0b1628")
        self._queue: queue.Queue = queue.Queue()
        self._busy = False
        self._last_project: Path | None = None
        self._integration_meta: dict = {}
        self._bridge_server = None
        self._bridge_token = get_or_create_token()
        self._bridge_loaded_job_id: str | None = None
        self._build_style()
        self._build_ui()
        self._load_saved_key()
        self._start_local_bridge()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(150, self._poll_queue)
        self.after(1800, self._poll_bridge_inbox)
        self.after(2200, self._refresh_health)

    def _build_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TFrame", background="#0b1628")
        style.configure("Card.TFrame", background="#12223a")
        style.configure("TLabel", background="#0b1628", foreground="white", font=("Segoe UI", 10))
        style.configure("Card.TLabel", background="#12223a", foreground="white", font=("Segoe UI", 10))
        style.configure("Title.TLabel", background="#0b1628", foreground="white", font=("Segoe UI", 21, "bold"))
        style.configure("Subtitle.TLabel", background="#0b1628", foreground="#9cc3ff", font=("Segoe UI", 10))
        style.configure("Section.TLabel", background="#12223a", foreground="white", font=("Segoe UI", 12, "bold"))
        style.configure("TNotebook", background="#0b1628", borderwidth=0)
        style.configure("TNotebook.Tab", font=("Segoe UI", 10))

    def _build_ui(self):
        head = ttk.Frame(self, padding=(16, 14, 16, 8))
        head.pack(fill="x")
        ttk.Label(head, text="Scout Video Analyzer Local V2.3", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            head,
            text="Vídeo → evidências auditáveis → JSON universal → revisão humana → PDF",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(4, 0))

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        self.analysis_tab = ttk.Frame(self.tabs, padding=12)
        self.config_tab = ttk.Frame(self.tabs, padding=12)
        self.bridge_tab = ttk.Frame(self.tabs, padding=12)
        self.health_tab = ttk.Frame(self.tabs, padding=12)
        self.tabs.add(self.analysis_tab, text="Análise")
        self.tabs.add(self.bridge_tab, text="Ponte Scout V74")
        self.tabs.add(self.health_tab, text="Saúde da análise")
        self.tabs.add(self.config_tab, text="Configuração")

        self._build_analysis()
        self._build_bridge_tab()
        self._build_health_tab()
        self._build_config()

        foot = ttk.Frame(self, padding=(14, 0, 14, 12))
        foot.pack(fill="x")
        self.status_var = tk.StringVar(value="Pronto.")
        ttk.Label(foot, textvariable=self.status_var, style="Subtitle.TLabel").pack(side="left", fill="x", expand=True)
        self.progress = ttk.Progressbar(foot, mode="determinate", maximum=100, length=250)
        self.progress.pack(side="right")

    def _card(self, parent, title: str):
        card = ttk.Frame(parent, style="Card.TFrame", padding=14)
        ttk.Label(card, text=title, style="Section.TLabel").pack(anchor="w", pady=(0, 10))
        return card

    def _build_analysis(self):
        outer = ttk.Frame(self.analysis_tab)
        outer.pack(fill="both", expand=True)
        left = ttk.Frame(outer)
        right = ttk.Frame(outer)
        left.pack(side="left", fill="both", expand=False, padx=(0, 8))
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))

        mode = self._card(left, "1. Tipo de análise")
        mode.pack(fill="x", pady=(0, 10))
        self.target_type = tk.StringVar(value="athlete")
        self.material_type = tk.StringVar(value="full_match")
        ttk.Label(mode, text="Alvo", style="Card.TLabel").pack(anchor="w")
        row = ttk.Frame(mode, style="Card.TFrame")
        row.pack(fill="x", pady=(3, 9))
        ttk.Radiobutton(row, text="Atleta", variable=self.target_type, value="athlete", command=self._refresh_mode).pack(side="left")
        ttk.Radiobutton(row, text="Equipe", variable=self.target_type, value="team", command=self._refresh_mode).pack(side="left", padx=(14, 0))
        ttk.Label(mode, text="Material", style="Card.TLabel").pack(anchor="w")
        row2 = ttk.Frame(mode, style="Card.TFrame")
        row2.pack(fill="x", pady=(3, 0))
        ttk.Radiobutton(row2, text="Jogo completo", variable=self.material_type, value="full_match", command=self._refresh_mode).pack(side="left")
        ttk.Radiobutton(row2, text="Melhores momentos", variable=self.material_type, value="highlights", command=self._refresh_mode).pack(side="left", padx=(14, 0))
        bridge_row = ttk.Frame(mode, style="Card.TFrame")
        bridge_row.pack(fill="x", pady=(10, 0))
        ttk.Button(bridge_row, text="Importar tarefa do Scout V74", command=self._import_scout_job).pack(side="left")
        self.bridge_status_var = tk.StringVar(value="Preenchimento manual ou tarefa scout.analyzer.job.v1")
        ttk.Label(bridge_row, textvariable=self.bridge_status_var, style="Card.TLabel", wraplength=245).pack(side="left", padx=(8, 0))

        info = self._card(left, "2. Contexto")
        info.pack(fill="x", pady=(0, 10))
        self.entries: dict[str, tuple[tk.StringVar, ttk.Entry]] = {}
        self.entry_rows: dict[str, ttk.Frame] = {}
        self.entry_labels: dict[str, ttk.Label] = {}
        self._entry(info, "Atleta *", "athlete_name")
        self._entry(info, "Equipe *", "team")
        self._entry(info, "Posição *", "position")
        self._entry(info, "Número/camisa *", "shirt_number")
        self._entry(info, "Adversário *", "opponent")
        self._entry(info, "Competição *", "competition")
        self._entry(info, "Data (opcional)", "match_date")
        self._entry(info, "Período/temporada (opcional)", "period")
        self._entry(info, "Observações (opcional)", "notes")

        source = self._card(left, "3. Fonte do vídeo")
        source.pack(fill="x")
        self.source_type = tk.StringVar(value="youtube")
        r = ttk.Frame(source, style="Card.TFrame")
        r.pack(fill="x", pady=(0, 8))
        ttk.Radiobutton(r, text="YouTube público", variable=self.source_type, value="youtube", command=self._refresh_mode).pack(side="left")
        ttk.Radiobutton(r, text="MP4 autorizado", variable=self.source_type, value="mp4", command=self._refresh_mode).pack(side="left", padx=(14, 0))
        ttk.Label(source, text="URL do YouTube", style="Card.TLabel").pack(anchor="w")
        self.youtube_var = tk.StringVar()
        self.youtube_entry = ttk.Entry(source, textvariable=self.youtube_var, width=50)
        self.youtube_entry.pack(fill="x", pady=(3, 7))
        ttk.Label(source, text="MP4 local", style="Card.TLabel").pack(anchor="w")
        mp4row = ttk.Frame(source, style="Card.TFrame")
        mp4row.pack(fill="x", pady=(3, 7))
        self.mp4_var = tk.StringVar()
        self.mp4_entry = ttk.Entry(mp4row, textvariable=self.mp4_var, width=36)
        self.mp4_entry.pack(side="left", fill="x", expand=True)
        self.mp4_btn = ttk.Button(mp4row, text="Selecionar", command=self._choose_mp4)
        self.mp4_btn.pack(side="left", padx=(6, 0))
        ttk.Label(
            source,
            text="Duração total (min) — necessária para YouTube longo; MP4 tenta detectar automaticamente",
            style="Card.TLabel",
            wraplength=390,
        ).pack(anchor="w")
        self.duration_var = tk.StringVar(value="105")
        ttk.Entry(source, textvariable=self.duration_var, width=12).pack(anchor="w", pady=(3, 0))

        model_card = self._card(right, "4. Modelo de Jogo (opcional)")
        model_card.pack(fill="both", expand=True, pady=(0, 10))
        ttk.Label(
            model_card,
            text="Cole princípios/critérios. Sem isso, a comparação não será inventada.",
            style="Card.TLabel",
        ).pack(anchor="w", pady=(0, 6))
        self.model_game = tk.Text(model_card, height=12, wrap="word")
        self.model_game.pack(fill="both", expand=True)

        result = self._card(right, "5. Processamento e resultado")
        result.pack(fill="x")
        self.sample_note_var = tk.StringVar()
        ttk.Label(result, textvariable=self.sample_note_var, style="Card.TLabel", wraplength=610).pack(anchor="w", pady=(0, 8))
        actions = ttk.Frame(result, style="Card.TFrame")
        actions.pack(fill="x")
        self.analyze_btn = ttk.Button(actions, text="Iniciar análise", command=self._start_new)
        self.analyze_btn.pack(side="left")
        self.resume_btn = ttk.Button(actions, text="Continuar análise", command=self._resume)
        self.resume_btn.pack(side="left", padx=(8, 0))
        self.open_btn = ttk.Button(actions, text="Abrir pasta do último projeto", command=self._open_last_project)
        self.open_btn.pack(side="left", padx=(8, 0))
        self.pdf_btn = ttk.Button(actions, text="Abrir PDF preliminar", command=self._open_report_pdf)
        self.pdf_btn.pack(side="left", padx=(8, 0))
        self.export_v3_btn = ttk.Button(actions, text="Exportar JSON V3 para o Scout", command=self._export_v3)
        self.export_v3_btn.pack(side="left", padx=(8, 0))
        self._refresh_mode()

    def _build_bridge_tab(self):
        card = self._card(self.bridge_tab, "Ponte automática Scout Intelligence ↔ Analyzer")
        card.pack(fill="x", pady=(0, 10))
        ttk.Label(
            card,
            text=(
                "A ponte local escuta somente neste computador (127.0.0.1:8765). "
                "No Windows, o Scout pode enviar a tarefa e buscar o resultado V3 sem procurar arquivos. "
                "No iPad/celular, use o JSON manual como fallback."
            ),
            style="Card.TLabel",
            wraplength=920,
        ).pack(anchor="w", pady=(0, 10))
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill="x")
        self.bridge_live_var = tk.StringVar(value="Iniciando ponte local...")
        ttk.Label(row, textvariable=self.bridge_live_var, style="Card.TLabel").pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Atualizar", command=self._refresh_bridge_tab).pack(side="right")
        token_card = self._card(self.bridge_tab, "Pareamento")
        token_card.pack(fill="x", pady=(0, 10))
        ttk.Label(token_card, text="Token local (copie uma vez para o Scout V74):", style="Card.TLabel").pack(anchor="w")
        token_row = ttk.Frame(token_card, style="Card.TFrame")
        token_row.pack(fill="x", pady=(5, 0))
        self.bridge_token_var = tk.StringVar(value=self._bridge_token)
        ttk.Entry(token_row, textvariable=self.bridge_token_var, state="readonly", width=58).pack(side="left", fill="x", expand=True)
        ttk.Button(token_row, text="Copiar token", command=self._copy_bridge_token).pack(side="left", padx=(7, 0))
        ttk.Button(token_row, text="Abrir pasta da ponte", command=self._open_bridge_folder).pack(side="left", padx=(7, 0))

        queue_card = self._card(self.bridge_tab, "Fila recebida do Scout")
        queue_card.pack(fill="both", expand=True)
        self.bridge_queue_var = tk.StringVar(value="Nenhuma tarefa recebida.")
        ttk.Label(queue_card, textvariable=self.bridge_queue_var, style="Card.TLabel", wraplength=920).pack(anchor="w", pady=(0, 8))
        qrow = ttk.Frame(queue_card, style="Card.TFrame")
        qrow.pack(fill="x")
        ttk.Button(qrow, text="Carregar próxima tarefa", command=self._load_next_bridge_job).pack(side="left")
        self.bridge_auto_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(qrow, text="Carregar automaticamente quando estiver livre", variable=self.bridge_auto_var).pack(side="left", padx=(14, 0))
        ttk.Label(
            queue_card,
            text=(
                "Segurança: o serviço fica limitado ao loopback deste Windows e exige o token para enviar tarefas, "
                "consultar status e ler resultados."
            ),
            style="Card.TLabel",
            wraplength=920,
        ).pack(anchor="w", pady=(10, 0))

    def _build_health_tab(self):
        card = self._card(self.health_tab, "Saúde da análise")
        card.pack(fill="both", expand=True)
        top = ttk.Frame(card, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(
            top,
            text="Diagnóstico do projeto atual: fonte, chunks, identificação, evidências, limitações e saídas.",
            style="Card.TLabel",
        ).pack(side="left", fill="x", expand=True)
        ttk.Button(top, text="Atualizar", command=self._refresh_health).pack(side="right")
        self.health_text = tk.Text(card, height=25, wrap="word", bg="#0d1b2d", fg="#e5eefc", insertbackground="white")
        self.health_text.pack(fill="both", expand=True)
        self.health_text.insert("1.0", "Nenhum projeto aberto nesta sessão.")
        self.health_text.configure(state="disabled")

    def _start_local_bridge(self):
        try:
            self._bridge_server, _thread, self._bridge_token = start_bridge_server(analyzer_version="2.3.0")
            if hasattr(self, "bridge_token_var"):
                self.bridge_token_var.set(self._bridge_token)
            self.bridge_live_var.set("● Ponte ativa em http://127.0.0.1:8765")
        except OSError as exc:
            self.bridge_live_var.set(f"⚠ Porta 8765 indisponível: {exc}. JSON manual continua disponível.")
        except Exception as exc:
            self.bridge_live_var.set(f"⚠ Ponte local não iniciada: {exc}. JSON manual continua disponível.")

    def _copy_bridge_token(self):
        try:
            self.clipboard_clear()
            self.clipboard_append(self._bridge_token)
            self.status_var.set("Token da ponte copiado.")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Não foi possível copiar o token: {exc}")

    def _open_bridge_folder(self):
        try:
            os.startfile(bridge_dirs()["base"])
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Não foi possível abrir a pasta da ponte: {exc}")

    def _refresh_bridge_tab(self):
        try:
            queued = list_jobs({"queued"})
            active = list_jobs({"loaded", "running"})
            done = list_jobs({"completed"})
            self.bridge_queue_var.set(
                f"Recebidas: {len(queued)} aguardando • {len(active)} em andamento • {len(done)} resultado(s) pronto(s)."
            )
            if self._bridge_server:
                self.bridge_live_var.set("● Ponte ativa em http://127.0.0.1:8765")
        except Exception as exc:
            self.bridge_queue_var.set(f"Falha ao ler a fila local: {exc}")

    def _apply_scout_job(self, job: dict, *, from_bridge: bool = False):
        parsed = parse_scout_job(job)
        self.target_type.set(parsed["target_type"])
        self.material_type.set(parsed["material_type"])
        self._refresh_mode()
        for key, value in parsed["fields"].items():
            if key in self.entries:
                self.entries[key][0].set(value or "")
        self.model_game.delete("1.0", "end")
        if parsed.get("model_game"):
            self.model_game.insert("1.0", parsed["model_game"])
        self.source_type.set(parsed["source_type"])
        self._refresh_mode()
        ref = parsed.get("source_reference") or ""
        if parsed["source_type"] == "youtube":
            self.youtube_var.set(ref)
            self.mp4_var.set("")
        else:
            self.youtube_var.set("")
            self.mp4_var.set(ref if ref and Path(ref).is_file() else "")
        self._integration_meta = parsed.get("integration") or {}
        jid = self._integration_meta.get("job_id") or str(job.get("job_id") or "")
        if jid:
            self._integration_meta["job_id"] = jid
            self._bridge_loaded_job_id = jid if from_bridge else None
            if from_bridge:
                mark_state(jid, "loaded", "Tarefa carregada no Analyzer; aguardando início.")
        self.bridge_status_var.set(f"Tarefa carregada: {jid or 'sem ID'}")
        self.status_var.set("Tarefa do Scout carregada. Confira contexto e fonte antes de iniciar.")
        self.tabs.select(self.analysis_tab)
        self._refresh_bridge_tab()
        warning = parsed.get("source_warning") or ""
        if warning and not from_bridge:
            messagebox.showinfo(APP_TITLE, "Tarefa carregada.\n\n" + warning)

    def _load_next_bridge_job(self):
        item = next_queued_job()
        if not item:
            self.status_var.set("Nenhuma tarefa aguardando na ponte local.")
            self._refresh_bridge_tab()
            return
        try:
            self._apply_scout_job(item["job"], from_bridge=True)
            self.status_var.set(f"Tarefa {item['job_id']} recebida do Scout e carregada.")
        except Exception as exc:
            mark_state(item["job_id"], "error", f"Falha ao carregar tarefa: {exc}")
            messagebox.showerror(APP_TITLE, f"Não foi possível carregar a tarefa recebida: {exc}")

    def _poll_bridge_inbox(self):
        try:
            self._refresh_bridge_tab()
            if self.bridge_auto_var.get() and not self._busy and not self._bridge_loaded_job_id:
                item = next_queued_job()
                if item:
                    self._apply_scout_job(item["job"], from_bridge=True)
                    self.status_var.set(f"Tarefa {item['job_id']} recebida automaticamente do Scout.")
        except Exception:
            pass
        self.after(1800, self._poll_bridge_inbox)

    def _health_snapshot(self) -> str:
        lines = ["SCOUT VIDEO ANALYZER — SAÚDE DA ANÁLISE", ""]
        lines.append(f"Ponte local: {'ATIVA' if self._bridge_server else 'INATIVA'} • http://127.0.0.1:8765")
        if self._bridge_loaded_job_id:
            st = read_state(self._bridge_loaded_job_id)
            lines.append(f"Tarefa atual: {self._bridge_loaded_job_id} • {st.get('status')} • {st.get('message','')}")
        else:
            lines.append("Tarefa atual: preenchimento manual / sem job da ponte")
        lines.append("")
        if not self._last_project or not self._last_project.exists():
            lines.append("Projeto: nenhum projeto aberto nesta sessão.")
            return "\n".join(lines)
        lines.append(f"Projeto: {self._last_project}")
        manifest_file = self._last_project / "manifest.json"
        try:
            manifest = read_json(manifest_file) if manifest_file.exists() else {}
        except Exception:
            manifest = {}
        lines.append(f"Status: {manifest.get('status','desconhecido')}")
        context = manifest.get("context") or {}
        source = context.get("source") or {}
        ref = source.get("url") or source.get("path") or "não informado"
        lines.append(f"Fonte: {source.get('type','?')} • {ref}")
        chunks_dir = self._last_project / "chunks"
        chunk_files = list(chunks_dir.glob("chunk_*.json")) if chunks_dir.exists() else []
        lines.append(f"Chunks salvos: {len(chunk_files)}")
        v2_file = self._last_project / "scout_analysis_v2.json"
        v3_file = self._last_project / "scout_analysis_v3.json"
        pdf_file = self._last_project / "scout_report_draft.pdf"
        if v2_file.exists():
            try:
                v2 = read_json(v2_file)
                events = v2.get("events") or []
                ident = v2.get("identification") or {}
                lines.append(f"Evidências: {len(events)}")
                lines.append(f"Confiança média de identificação: {round(float(ident.get('confidence_mean',0))*100)}%")
                lines.append(f"Limitações registradas: {len(v2.get('limitations') or [])}")
                proc = v2.get("processing") or {}
                lines.append(f"Síntese: {proc.get('synthesis_status','?')} • modelo {proc.get('model','?')}")
            except Exception as exc:
                lines.append(f"V2: erro de leitura — {exc}")
        else:
            lines.append("V2: ainda não gerado")
        lines.append(f"JSON V3: {'OK' if v3_file.exists() else 'pendente'}")
        lines.append(f"PDF preliminar: {'OK' if pdf_file.exists() else 'pendente'}")
        if self._bridge_loaded_job_id:
            lines.append(f"Entrega automática ao Scout: {'pronta' if read_state(self._bridge_loaded_job_id).get('status') == 'completed' else 'pendente'}")
        lines.append("")
        lines.append("Interpretação: estes indicadores medem saúde do processamento e cobertura de evidências; não são nota esportiva do atleta/equipe.")
        return "\n".join(lines)

    def _refresh_health(self):
        if not hasattr(self, "health_text"):
            return
        try:
            text = self._health_snapshot()
            self.health_text.configure(state="normal")
            self.health_text.delete("1.0", "end")
            self.health_text.insert("1.0", text)
            self.health_text.configure(state="disabled")
        except Exception:
            pass

    def _on_close(self):
        try:
            if self._bridge_server:
                self._bridge_server.shutdown()
                self._bridge_server.server_close()
        except Exception:
            pass
        self.destroy()

    def _build_config(self):
        card = self._card(self.config_tab, "Gemini")
        card.pack(fill="x")

        # _card() uses pack for the section title; keep grid inside a child frame.
        form = ttk.Frame(card, style="Card.TFrame")
        form.pack(fill="x")
        ttk.Label(form, text="Chave Gemini API", style="Card.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=5)
        self.api_key_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.api_key_var, show="•", width=85).grid(row=0, column=1, sticky="ew", pady=5)
        ttk.Label(form, text="Modelo", style="Card.TLabel").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=5)
        self.model_var = tk.StringVar(value="gemini-3.7-flash")
        ttk.Entry(form, textvariable=self.model_var).grid(row=1, column=1, sticky="ew", pady=5)
        self.save_key_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            form,
            text="Guardar chave no gerenciador de credenciais do Windows",
            variable=self.save_key_var,
        ).grid(row=2, column=1, sticky="w", pady=5)
        ttk.Button(form, text="Validar chave/modelo", command=self._validate_key).grid(row=3, column=1, sticky="w", pady=8)
        form.columnconfigure(1, weight=1)

        privacy = self._card(self.config_tab, "Comportamento da V2")
        privacy.pack(fill="x", pady=(12, 0))
        text = (
            "• Jogo completo é processado em blocos estáticos de ~8 minutos, com sobreposição curta.\n"
            "• Em Atleta → Melhores momentos, atleta e posição são obrigatórios; equipe/camisa não são exigidas.\n"
            "• Grafismos do vídeo (círculo, seta, zoom, destaque) são usados como pista de identidade quando presentes.\n"
            "• Em Equipe → Melhores momentos, somente a equipe é obrigatória; o restante do contexto é opcional.\n"
            "• MP4 autorizado é enviado uma vez à Files API e reutilizado pelos blocos; o Analyzer tenta apagá-lo ao final.\n"
            "• Cada bloco concluído é salvo localmente. Se houver falha, use Continuar análise.\n"
            "• O Gemini produz evidências simples; o aplicativo é dono do JSON final.\n"
            "• A V2.1 separa confiança de identificação, ação e contexto.\n"
            "• Além do JSON V2, gera scout.analysis.v3 para Audit Scout/outras plataformas e PDF preliminar.\n"
            "• Melhores momentos são amostra selecionada e não sustentam conclusões de consistência.\n"
            "• Nenhuma avaliação é confirmada automaticamente: revisão humana permanece obrigatória."
        )
        ttk.Label(privacy, text=text, style="Card.TLabel", justify="left", wraplength=950).pack(anchor="w")

    def _entry(self, parent, label: str, key: str):
        row = ttk.Frame(parent, style="Card.TFrame")
        row.pack(fill="x", pady=3)
        label_widget = ttk.Label(row, text=label, style="Card.TLabel", width=25)
        label_widget.pack(side="left")
        var = tk.StringVar()
        ent = ttk.Entry(row, textvariable=var, width=32)
        ent.pack(side="left", fill="x", expand=True)
        self.entries[key] = (var, ent)
        self.entry_rows[key] = row
        self.entry_labels[key] = label_widget

    def _show_context_entry(self, key: str, label: str):
        self.entry_labels[key].configure(text=label)
        self.entries[key][1].configure(state="normal")
        self.entry_rows[key].pack(fill="x", pady=3)

    def _refresh_mode(self):
        target = self.target_type.get()
        material = self.material_type.get()

        # Rebuild only the visible context rows. Hidden fields keep their text but
        # are ignored by _collect_context(), so changing modes does not leak data.
        for row in self.entry_rows.values():
            row.pack_forget()

        if target == "athlete" and material == "full_match":
            fields = [
                ("athlete_name", "Atleta *"),
                ("team", "Equipe *"),
                ("position", "Posição *"),
                ("shirt_number", "Número/camisa *"),
                ("opponent", "Adversário *"),
                ("competition", "Competição *"),
                ("match_date", "Data (opcional)"),
            ]
            note = "Atleta + jogo completo: equipe, camisa, adversário e competição ajudam a identificar o jogador ao longo da partida."
        elif target == "athlete" and material == "highlights":
            fields = [
                ("athlete_name", "Atleta *"),
                ("position", "Posição *"),
                ("team", "Equipe(s) (opcional)"),
                ("opponent", "Adversário(s) (opcional)"),
                ("competition", "Competição(ões) (opcional)"),
                ("period", "Período/temporada (opcional)"),
                ("notes", "Observações (opcional)"),
            ]
            note = (
                "Atleta + melhores momentos: atleta e posição são obrigatórios. O compilado pode reunir clubes, camisas e competições diferentes; "
                "quando houver círculo/seta/zoom/destaque, o Analyzer usa esse grafismo como pista de identificação."
            )
        elif target == "team" and material == "full_match":
            fields = [
                ("team", "Equipe *"),
                ("opponent", "Adversário *"),
                ("competition", "Competição *"),
                ("match_date", "Data (opcional)"),
            ]
            note = "Equipe + jogo completo: equipe, adversário e competição formam o contexto principal da partida."
        else:
            fields = [
                ("team", "Equipe *"),
                ("opponent", "Adversário(s) (opcional)"),
                ("competition", "Competição(ões) (opcional)"),
                ("period", "Período/temporada (opcional)"),
                ("notes", "Observações (opcional)"),
            ]
            note = (
                "Equipe + melhores momentos: somente a equipe é obrigatória. Adversários, competições, período e observações são contexto opcional; "
                "o Analyzer não inventa o que não estiver visível ou informado."
            )

        for key, label in fields:
            self._show_context_entry(key, label)

        youtube = self.source_type.get() == "youtube"
        self.youtube_entry.configure(state="normal" if youtube else "disabled")
        self.mp4_entry.configure(state="disabled" if youtube else "normal")
        self.mp4_btn.configure(state="disabled" if youtube else "normal")

        if material == "highlights":
            self.sample_note_var.set(note + " Melhores momentos continuam sendo amostra selecionada e não provam consistência em 90 minutos.")
            if self.duration_var.get().strip() == "105":
                self.duration_var.set("")
        else:
            self.sample_note_var.set(note + " O vídeo será processado em blocos independentes e as evidências serão salvas antes da síntese.")
            if not self.duration_var.get().strip():
                self.duration_var.set("105")

    def _import_scout_job(self):
        path = filedialog.askopenfilename(
            title="Selecione a tarefa exportada pelo Scout Intelligence V74",
            filetypes=[("Tarefa Scout Analyzer", "*.json"), ("JSON", "*.json")],
        )
        if not path:
            return
        try:
            self._apply_scout_job(read_json(path), from_bridge=False)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Não foi possível abrir a tarefa do Scout: {exc}")

    def _export_v3(self):
        if not self._last_project or not self._last_project.exists():
            messagebox.showinfo(APP_TITLE, "Nenhum projeto foi criado/aberto nesta sessão.")
            return
        source = self._last_project / "scout_analysis_v3.json"
        if not source.exists():
            messagebox.showinfo(APP_TITLE, "O JSON scout.analysis.v3 ainda não foi gerado para este projeto.")
            return
        target = filedialog.asksaveasfilename(
            title="Salvar JSON V3 para importar no Scout Intelligence",
            defaultextension=".json",
            initialfile=f"Scout_Analysis_V3_{self._last_project.name}.json",
            filetypes=[("JSON", "*.json")],
        )
        if not target:
            return
        try:
            shutil.copy2(source, target)
            self.status_var.set("JSON V3 exportado. Agora importe-o na aba Video Analyzer / Audit do Scout.")
            messagebox.showinfo(APP_TITLE, f"JSON V3 pronto para o Scout Intelligence:\n{target}")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Não foi possível exportar o JSON V3: {exc}")

    def _choose_mp4(self):
        path = filedialog.askopenfilename(
            title="Selecionar MP4 autorizado",
            filetypes=[("Vídeo MP4", "*.mp4"), ("Todos os arquivos", "*.*")],
        )
        if path:
            self.mp4_var.set(path)

    def _load_saved_key(self):
        try:
            saved = keyring.get_password(KEYRING_SERVICE, KEYRING_USER)
            if saved:
                self.api_key_var.set(saved)
        except Exception:
            pass

    def _save_key(self):
        if self.save_key_var.get() and self.api_key_var.get().strip():
            try:
                keyring.set_password(KEYRING_SERVICE, KEYRING_USER, self.api_key_var.get().strip())
            except Exception:
                pass

    def _validate_key(self):
        key = self.api_key_var.get().strip()
        model = self.model_var.get().strip()
        if not key or not model:
            messagebox.showwarning(APP_TITLE, "Informe a chave Gemini e o modelo.")
            return
        self._set_busy(True, "Validando chave/modelo...")

        def worker():
            try:
                msg = validate_api_key(key, model)
                self._queue.put(("info", "Chave/modelo respondendo corretamente. " + msg))
                self._save_key()
            except Exception as exc:
                self._queue.put(("error", f"Falha ao validar: {exc}"))
            finally:
                self._queue.put(("busy", False))

        threading.Thread(target=worker, daemon=True).start()

    @staticmethod
    def _split_multi(value: str) -> list[str]:
        if not value.strip():
            return []
        parts = re.split(r"[;|,\n]+", value)
        out: list[str] = []
        for part in parts:
            item = part.strip()
            if item and item not in out:
                out.append(item)
        return out

    def _collect_context(self):
        data = {k: var.get().strip() for k, (var, _ent) in self.entries.items()}
        target = self.target_type.get()
        material = self.material_type.get()

        if target == "athlete" and material == "full_match":
            missing = [
                label
                for key, label in (
                    ("athlete_name", "atleta"),
                    ("team", "equipe"),
                    ("position", "posição"),
                    ("shirt_number", "camisa"),
                    ("opponent", "adversário"),
                    ("competition", "competição"),
                )
                if not data[key]
            ]
            if missing:
                raise ValueError("Para Atleta + Jogo completo, informe: " + ", ".join(missing) + ".")
        elif target == "athlete" and material == "highlights":
            if not data["athlete_name"] or not data["position"]:
                raise ValueError("Para Atleta + Melhores momentos, informe apenas atleta e posição como campos obrigatórios.")
        elif target == "team" and material == "full_match":
            missing = [label for key, label in (("team", "equipe"), ("opponent", "adversário"), ("competition", "competição")) if not data[key]]
            if missing:
                raise ValueError("Para Equipe + Jogo completo, informe: " + ", ".join(missing) + ".")
        else:
            if not data["team"]:
                raise ValueError("Para Equipe + Melhores momentos, informe a equipe. Os demais campos são opcionais.")

        source_type = self.source_type.get()
        if source_type == "youtube":
            url = self.youtube_var.get().strip()
            if "youtube.com/" not in url and "youtu.be/" not in url:
                raise ValueError("Informe uma URL pública válida do YouTube.")
            source = {"type": "youtube", "url": url}
        else:
            path = self.mp4_var.get().strip()
            if not path or not Path(path).is_file():
                raise ValueError("Selecione um MP4 autorizado existente.")
            source = {"type": "mp4", "path": path}

        duration = None
        if self.duration_var.get().strip():
            try:
                duration = float(self.duration_var.get().replace(",", "."))
                if duration <= 0:
                    duration = None
            except Exception:
                raise ValueError("Duração total deve ser um número em minutos, por exemplo 105.")
        if source_type == "youtube" and material == "full_match" and not duration:
            raise ValueError("Para jogo completo no YouTube, informe a duração total aproximada em minutos.")

        if material == "full_match":
            team = data["team"]
            opponent = data["opponent"]
            competition = data["competition"]
            teams_context = [team] if team else []
            opponents_context = [opponent] if opponent else []
            competitions_context = [competition] if competition else []
            period = None
            notes = None
            match_date = data["match_date"] or None
        else:
            # Highlights may mix games. Athlete compilations may even mix clubs and shirt numbers.
            if target == "athlete":
                team = None
                teams_context = self._split_multi(data["team"])
            else:
                team = data["team"]
                teams_context = [team] if team else []
            opponent = None
            competition = None
            opponents_context = self._split_multi(data["opponent"])
            competitions_context = self._split_multi(data["competition"])
            period = data["period"] or None
            notes = data["notes"] or None
            match_date = None

        return {
            "target_type": target,
            "material_type": material,
            "athlete_name": data["athlete_name"] or None if target == "athlete" else None,
            "team": team,
            "teams_context": teams_context,
            "position": data["position"] or None if target == "athlete" else None,
            "shirt_number": data["shirt_number"] or None if (target == "athlete" and material == "full_match") else None,
            "opponent": opponent,
            "opponents_context": opponents_context,
            "competition": competition,
            "competitions_context": competitions_context,
            "match_date": match_date,
            "period": period,
            "notes": notes,
            "model_game": self.model_game.get("1.0", "end").strip(),
            "duration_minutes": duration,
            "source": source,
            "identification_strategy": (
                "visual_graphics_preferred_when_present"
                if target == "athlete" and material == "highlights"
                else "match_context_and_visual_continuity"
            ),
            "integration": dict(self._integration_meta or {}),
            "team_roster": list((self._integration_meta or {}).get("roster") or []),
        }

    def _start_new(self):
        if self._busy:
            return
        try:
            context = self._collect_context()
            key = self.api_key_var.get().strip()
            model = self.model_var.get().strip()
            if not key or not model:
                raise ValueError("Abra Configuração e informe a chave Gemini e o modelo.")
        except Exception as exc:
            messagebox.showwarning(APP_TITLE, str(exc))
            return
        parent = filedialog.askdirectory(title="Escolha onde salvar o projeto de análise V2.3")
        if not parent:
            return
        try:
            project = create_project(parent, context)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Não foi possível criar o projeto: {exc}")
            return
        self._last_project = project
        if self._bridge_loaded_job_id:
            mark_state(self._bridge_loaded_job_id, "running", "Análise iniciada no Analyzer.", project_dir=str(project))
        self._save_key()
        self._refresh_health()
        self._run_project_thread(project, key, model)

    def _resume(self):
        if self._busy:
            return
        manifest_file = filedialog.askopenfilename(
            title="Selecione manifest.json do projeto",
            filetypes=[("Manifest Scout V2", "manifest.json"), ("JSON", "*.json")],
        )
        if not manifest_file:
            return
        path = Path(manifest_file)
        try:
            manifest = read_json(path)
            if manifest.get("schema_version") != "scout.video_analysis.project.v2":
                raise ValueError("Este arquivo não é um projeto Scout Video Analyzer V2.")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Projeto inválido: {exc}")
            return
        key = self.api_key_var.get().strip()
        model = self.model_var.get().strip()
        if not key or not model:
            messagebox.showwarning(APP_TITLE, "Abra Configuração e informe a chave Gemini e o modelo.")
            return
        self._last_project = path.parent
        try:
            integration = ((manifest.get("context") or {}).get("integration") or {})
            jid = integration.get("job_id")
            if jid:
                self._integration_meta = dict(integration)
                self._bridge_loaded_job_id = str(jid)
                mark_state(str(jid), "running", "Projeto retomado no Analyzer.", project_dir=str(path.parent))
        except Exception:
            pass
        self._save_key()
        self._refresh_health()
        self._run_project_thread(path.parent, key, model)

    def _run_project_thread(self, project: Path, key: str, model: str):
        self._set_busy(True, "Iniciando projeto V2.3...")
        self.progress["value"] = 1

        def worker():
            try:
                final_path = run_project(
                    project_dir=project,
                    api_key=key,
                    model=model,
                    status_cb=lambda text, prog: self._queue.put(("status", text, prog)),
                )
                if self._bridge_loaded_job_id:
                    try:
                        result = read_json(final_path)
                        publish_result(self._bridge_loaded_job_id, result, project_dir=str(project))
                    except Exception as bridge_exc:
                        mark_state(self._bridge_loaded_job_id, "error", f"Análise concluída, mas falhou a entrega automática: {bridge_exc}")
                self._queue.put(("done", str(final_path)))
            except Exception as exc:
                self._write_analysis_log(exc)
                if self._bridge_loaded_job_id:
                    try:
                        mark_state(self._bridge_loaded_job_id, "error", f"{type(exc).__name__}: {exc}")
                    except Exception:
                        pass
                self._queue.put(
                    (
                        "error",
                        "A análise foi pausada, mas os blocos concluídos foram preservados.\n\n"
                        f"{type(exc).__name__}: {exc}\n\nUse 'Continuar análise' depois de corrigir a causa.",
                    )
                )
            finally:
                self._queue.put(("busy", False))

        threading.Thread(target=worker, daemon=True).start()

    def _set_busy(self, busy: bool, status: str | None = None):
        self._busy = busy
        state = "disabled" if busy else "normal"
        self.analyze_btn.configure(state=state)
        self.resume_btn.configure(state=state)
        if status:
            self.status_var.set(status)

    def _poll_queue(self):
        try:
            while True:
                item = self._queue.get_nowait()
                kind = item[0]
                if kind == "status":
                    self.status_var.set(item[1])
                    if item[2] is not None:
                        self.progress["value"] = max(0, min(100, float(item[2]) * 100))
                elif kind == "busy":
                    self._set_busy(bool(item[1]))
                elif kind == "info":
                    messagebox.showinfo(APP_TITLE, item[1])
                elif kind == "error":
                    messagebox.showerror(APP_TITLE, item[1])
                elif kind == "done":
                    self.progress["value"] = 100
                    self.status_var.set("Concluído. JSON universal V3 e PDF preliminar prontos para revisão humana.")
                    messagebox.showinfo(
                        APP_TITLE,
                        "Análise concluída.\n\n"
                        f"JSON universal salvo em:\n{item[1]}\n\n"
                        "Na pasta do projeto também ficam scout_analysis_v2.json, evidence.json e scout_report_draft.pdf."
                    )
                    self._refresh_health()
                    self._refresh_bridge_tab()
                    if self._bridge_loaded_job_id and read_state(self._bridge_loaded_job_id).get("status") == "completed":
                        self.bridge_status_var.set(f"Resultado entregue pela ponte: {self._bridge_loaded_job_id}")
                        self._bridge_loaded_job_id = None
        except queue.Empty:
            pass
        self.after(150, self._poll_queue)

    def _open_last_project(self):
        if not self._last_project or not self._last_project.exists():
            messagebox.showinfo(APP_TITLE, "Nenhum projeto foi criado nesta sessão ainda.")
            return
        try:
            os.startfile(str(self._last_project))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Não foi possível abrir a pasta: {exc}")

    def _open_report_pdf(self):
        if not self._last_project or not self._last_project.exists():
            messagebox.showinfo(APP_TITLE, "Nenhum projeto foi criado nesta sessão ainda.")
            return
        pdf = self._last_project / "scout_report_draft.pdf"
        if not pdf.exists():
            messagebox.showinfo(APP_TITLE, "O PDF preliminar ainda não foi gerado para este projeto.")
            return
        try:
            os.startfile(str(pdf))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Não foi possível abrir o PDF: {exc}")

    def _write_analysis_log(self, exc: Exception):
        try:
            path = LOG_DIR / "analysis.log"
            with path.open("a", encoding="utf-8") as f:
                f.write("\n" + "=" * 78 + "\n")
                f.write(datetime.now().isoformat(timespec="seconds") + "\n")
                f.write(traceback.format_exc())
        except Exception:
            pass


if __name__ == "__main__":
    ScoutAnalyzerV2().mainloop()
