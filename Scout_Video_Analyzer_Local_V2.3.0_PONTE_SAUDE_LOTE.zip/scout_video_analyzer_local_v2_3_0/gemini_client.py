from __future__ import annotations

import random
import time
from typing import Callable, Any

from google import genai
from google.genai import types

from utils import safe_json_loads, parse_duration_seconds

StatusCallback = Callable[[str], None] | None
TRANSIENT_MARKERS = (
    "503", "502", "504", "429", "unavailable", "high demand", "temporarily",
    "server disconnected", "remoteprotocolerror", "connection reset", "timeout",
    "timed out", "resource_exhausted", "resource exhausted", "bad gateway",
)


def _status(cb: StatusCallback, text: str) -> None:
    if cb:
        cb(text)


def make_client(api_key: str, timeout_ms: int = 180_000):
    return genai.Client(
        api_key=api_key,
        http_options=types.HttpOptions(
            timeout=timeout_ms,
            retry_options=types.HttpRetryOptions(
                attempts=2,
                initial_delay=1.5,
                max_delay=8.0,
                exp_base=2.0,
                jitter=1.0,
                http_status_codes=[408, 429, 500, 502, 503, 504],
            ),
        ),
    )


def validate_api_key(api_key: str, model: str) -> str:
    client = make_client(api_key, timeout_ms=45_000)
    info = client.models.get(model=model)
    display = getattr(info, "display_name", None) or getattr(info, "name", None) or model
    return f"Modelo disponível: {display}"


def upload_video(api_key: str, path: str, status_cb: StatusCallback = None):
    client = make_client(api_key, timeout_ms=300_000)
    _status(status_cb, "Enviando MP4 autorizado para a Files API do Gemini...")
    uploaded = client.files.upload(file=path)
    name = getattr(uploaded, "name", None)
    if not name:
        raise RuntimeError("A Files API não retornou um identificador para o vídeo.")

    last = ""
    for _ in range(360):
        current = client.files.get(name=name)
        state_obj = getattr(current, "state", None)
        state = getattr(state_obj, "name", None) or str(state_obj or "")
        if state != last:
            _status(status_cb, f"Preparando vídeo no Gemini: {state or 'aguardando'}")
            last = state
        upper = state.upper()
        if "ACTIVE" in upper:
            duration = extract_file_duration_seconds(current)
            return current, duration
        if "FAILED" in upper:
            raise RuntimeError("O Gemini informou falha ao processar o MP4 enviado.")
        time.sleep(5)
    raise TimeoutError("O upload foi concluído, mas o processamento do arquivo demorou além do limite de espera.")


def delete_uploaded_file(api_key: str, file_name: str | None) -> None:
    if not file_name:
        return
    try:
        make_client(api_key, timeout_ms=60_000).files.delete(name=file_name)
    except Exception:
        pass


def extract_file_duration_seconds(file_obj: Any) -> float | None:
    candidates: list[Any] = []
    for attr in ("video_metadata", "videoMetadata", "metadata"):
        obj = getattr(file_obj, attr, None)
        if obj is not None:
            candidates.append(obj)
    try:
        dumped = file_obj.model_dump(exclude_none=True)
        candidates.append(dumped)
    except Exception:
        pass

    def walk(obj: Any) -> float | None:
        if obj is None:
            return None
        if isinstance(obj, dict):
            for key in ("video_duration", "videoDuration", "duration"):
                if key in obj:
                    val = parse_duration_seconds(obj[key])
                    if val:
                        return val
            for key in ("video_metadata", "videoMetadata", "metadata"):
                if key in obj:
                    val = walk(obj[key])
                    if val:
                        return val
        else:
            for key in ("video_duration", "videoDuration", "duration"):
                val = parse_duration_seconds(getattr(obj, key, None))
                if val:
                    return val
        return None

    for c in candidates:
        val = walk(c)
        if val:
            return val
    return None


def analyze_video_window(*, api_key: str, model: str, file_uri: str,
                         prompt: str, start_s: float | None, end_s: float | None,
                         mime_type: str | None = None, status_cb: StatusCallback = None) -> dict:
    client = make_client(api_key, timeout_ms=240_000)
    file_data = types.FileData(file_uri=file_uri)
    if mime_type:
        # Some SDK versions accept mime_type in FileData; if this assignment is
        # rejected we fall back to URI-only, which is sufficient for Files API.
        try:
            file_data = types.FileData(file_uri=file_uri, mime_type=mime_type)
        except Exception:
            pass

    kwargs: dict[str, Any] = {"file_data": file_data}
    if start_s is not None and end_s is not None:
        kwargs["video_metadata"] = types.VideoMetadata(
            start_offset=f"{max(0.0, float(start_s)):.3f}s",
            end_offset=f"{max(0.0, float(end_s)):.3f}s",
        )
    video_part = types.Part(**kwargs)
    contents = types.Content(parts=[video_part, types.Part(text=prompt)])

    config_variants = []
    try:
        config_variants.append(types.GenerateContentConfig(
            response_mime_type="application/json",
            media_resolution=types.MediaResolution.MEDIA_RESOLUTION_LOW,
            temperature=0.2,
        ))
    except Exception:
        pass
    config_variants.append(types.GenerateContentConfig(
        response_mime_type="application/json",
        temperature=0.2,
    ))
    config_variants.append(None)

    last_exc: Exception | None = None
    for attempt in range(1, 4):
        for idx, config in enumerate(config_variants):
            try:
                _status(status_cb, f"Gemini analisando trecho (tentativa {attempt})...")
                if config is None:
                    response = client.models.generate_content(model=model, contents=contents)
                else:
                    response = client.models.generate_content(model=model, contents=contents, config=config)
                text = getattr(response, "text", None) or ""
                data = safe_json_loads(text)
                if not isinstance(data, dict):
                    raise ValueError("O Gemini não retornou um objeto JSON nesta etapa.")
                return data
            except Exception as exc:
                last_exc = exc
                text = f"{type(exc).__name__}: {exc}".lower()
                # If the first config variant is incompatible, try the simpler one immediately.
                config_issue = any(s in text for s in ("unexpected keyword", "media_resolution", "invalid argument"))
                if config_issue and idx < len(config_variants) - 1:
                    continue
                if not _is_transient(exc):
                    raise
                break
        if attempt < 3:
            wait = min(18.0, (2 ** attempt) + random.uniform(0.5, 2.0))
            _status(status_cb, f"Serviço temporariamente indisponível. Nova tentativa em {wait:.0f}s...")
            time.sleep(wait)
    assert last_exc is not None
    raise last_exc


def synthesize_text_json(*, api_key: str, model: str, prompt: str,
                         status_cb: StatusCallback = None) -> dict:
    client = make_client(api_key, timeout_ms=180_000)
    try:
        config = types.GenerateContentConfig(response_mime_type="application/json", temperature=0.2)
    except Exception:
        config = None
    last_exc: Exception | None = None
    for attempt in range(1, 4):
        try:
            _status(status_cb, f"Gerando síntese final (tentativa {attempt})...")
            if config is None:
                response = client.models.generate_content(model=model, contents=prompt)
            else:
                try:
                    response = client.models.generate_content(model=model, contents=prompt, config=config)
                except Exception as cfg_exc:
                    if "invalid argument" in str(cfg_exc).lower() or "unexpected keyword" in str(cfg_exc).lower():
                        response = client.models.generate_content(model=model, contents=prompt)
                    else:
                        raise
            data = safe_json_loads(getattr(response, "text", None) or "")
            if not isinstance(data, dict):
                raise ValueError("A síntese do Gemini não retornou um objeto JSON.")
            return data
        except Exception as exc:
            last_exc = exc
            if not _is_transient(exc) or attempt == 3:
                raise
            time.sleep(min(15.0, (2 ** attempt) + random.uniform(0.5, 1.5)))
    assert last_exc is not None
    raise last_exc


def _is_transient(exc: Exception) -> bool:
    code = getattr(exc, "code", None)
    try:
        if code is not None and int(code) in {408, 429, 500, 502, 503, 504}:
            return True
    except Exception:
        pass
    text = f"{type(exc).__name__}: {exc}".lower()
    return any(marker in text for marker in TRANSIENT_MARKERS)
