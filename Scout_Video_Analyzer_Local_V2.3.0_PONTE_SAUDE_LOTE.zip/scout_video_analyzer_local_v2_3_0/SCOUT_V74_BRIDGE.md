# Ponte Scout Intelligence V74.3 ↔ Analyzer Local V2.3.0

## Modo automático no Windows
1. Abra o Analyzer Local V2.3.0.
2. Abra a aba **Ponte Scout V74**.
3. Copie o token local.
4. No Scout V74.3, abra **Video Analyzer / Audit** e cole o token na Ponte automática.
5. Clique **Testar ponte**.
6. Selecione alvo/material e clique **Enviar direto**.
7. No Analyzer, a tarefa entra na fila local. Confira os dados e clique **Iniciar análise**.
8. Quando terminar, o Analyzer publica `scout.analysis.v3` na ponte; o Scout busca o resultado e abre a revisão humana.

A ponte escuta apenas `127.0.0.1:8765`, exige token e não publica o Analyzer na internet.

## Fallback universal
Se o navegador, rede local ou dispositivo não puder acessar o loopback — especialmente iPad/celular — use:
**Scout → Preparar tarefa JSON → Analyzer → Exportar JSON V3 → Scout → Importar análise JSON.**

O fallback contém o mesmo contrato de evidências e revisão humana.
