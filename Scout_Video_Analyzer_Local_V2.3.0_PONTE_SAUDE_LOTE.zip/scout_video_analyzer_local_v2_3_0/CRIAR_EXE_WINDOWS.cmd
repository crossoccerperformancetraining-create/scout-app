@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Criar Scout Video Analyzer V2 EXE

call "%~dp0_PREPARAR_AMBIENTE.cmd"
if errorlevel 1 exit /b %errorlevel%

set "VENV=%LOCALAPPDATA%\ScoutVideoAnalyzerLocalV2\venv"
set "BUILDROOT=%LOCALAPPDATA%\ScoutVideoAnalyzerLocalV2\pyinstaller"
set "DIST=%USERPROFILE%\ScoutVideoAnalyzerV2Dist"

if exist "%BUILDROOT%" rmdir /s /q "%BUILDROOT%"
if not exist "%BUILDROOT%" mkdir "%BUILDROOT%"
if not exist "%DIST%" mkdir "%DIST%"

echo Instalando/atualizando PyInstaller...
"%VENV%\Scripts\python.exe" -m pip install --upgrade pyinstaller || goto :fail

echo Gerando executavel fora do OneDrive...
"%VENV%\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --name "ScoutVideoAnalyzerV2" --workpath "%BUILDROOT%\build" --specpath "%BUILDROOT%\spec" --distpath "%DIST%" --collect-all keyring "%~dp0app.py"
if errorlevel 1 goto :fail

echo.
echo EXE criado em:
echo %DIST%\ScoutVideoAnalyzerV2\ScoutVideoAnalyzerV2.exe
pause
exit /b 0

:fail
echo Falha ao gerar o executavel. Abra DIAGNOSTICO_SCOUT.cmd se necessario.
pause
exit /b 1
