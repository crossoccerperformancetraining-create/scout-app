# Scout Video Analyzer Local V2.3.0

A V2.3 mantém o motor estável por blocos, a camada de qualidade/auditoria e adiciona a ponte direta de tarefas com o **Scout Intelligence V74**.

## V2.3 — ponte automática + saúde da análise + lote de equipe

A V2.3 acrescenta uma ponte HTTP **somente local** em `127.0.0.1:8765`, protegida por token. No Windows, o Scout Intelligence V74.3 pode enviar uma tarefa diretamente, acompanhar `queued / loaded / running / completed / error` e buscar o `scout.analysis.v3` quando o processamento terminar. O fluxo por arquivo JSON continua disponível e deve ser usado como fallback, especialmente no iPad/celular.

No aplicativo há duas novas abas: **Ponte Scout V74** (token, fila recebida e status) e **Saúde da análise** (fonte, chunks, evidências, confiança de identificação, limitações, V3 e PDF). Em análise de equipe, se o Scout enviar o elenco do jogo, o Analyzer pode registrar `observed_player_name / observed_player_id` somente quando houver base visual suficiente. Isso permite ao Scout criar revisões individuais a partir de uma análise coletiva sem inventar identidade.

A ponte não aplica nota, decisão, recomendação ou avaliação humana. Ela apenas transporta tarefa e resultado estruturado.

## Fluxo

1. Vídeo (YouTube público ou MP4 autorizado).
2. Análise em blocos independentes.
3. Evidências com timestamps.
4. Síntese sem reenviar o vídeo.
5. JSON local de compatibilidade: `scout_analysis_v2.json`.
6. Contrato universal: `scout_analysis_v3.json` (`schema_version = scout.analysis.v3`).
7. PDF preliminar: `scout_report_draft.pdf`.
8. Revisão humana obrigatória antes de qualquer decisão oficial.

## Modos

- Atleta + Jogo completo
- Atleta + Melhores momentos
- Equipe + Jogo completo
- Equipe + Melhores momentos

As regras de formulário dinâmico da V2.0.3 foram mantidas. Em Atleta + Melhores momentos, apenas atleta e posição são obrigatórios; em Equipe + Melhores momentos, apenas a equipe é obrigatória.

## Ponte com Scout Intelligence V74

A V2.3.0 importa tarefas `scout.analyzer.job.v1` geradas pelo Scout Intelligence. O botão **Importar tarefa do Scout V74** preenche alvo, material e contexto sem trazer nota ou decisão esportiva. Ao final, use **Exportar JSON V3 para o Scout** e faça a revisão humana na aba Video Analyzer / Audit.

Leia `SCOUT_V74_BRIDGE.md` para o passo a passo.

## Novidades de qualidade da V2.3.0

### 1. Confianças separadas

Cada evidência passa a separar:

- confiança de identificação do atleta/equipe;
- confiança da ação/comportamento observado;
- confiança do contexto (equipe, adversário, camisa, competição);
- confiança geral conservadora.

Isso evita misturar incerteza de identidade com clareza da ação.

### 2. Nome informado x nome observado

O nome digitado pelo usuário nunca é sobrescrito pelo que a IA lê no vídeo.

O resultado pode manter, por exemplo:

- `name_informed`: nome usado para iniciar a análise;
- `name_observed`: nome lido em cartão/grafismo;
- `observed_aliases`: apelidos ou formas alternativas vistas no material.

### 3. Resultado objetivo da ação

Além do campo legado `outcome`, cada evento possui `result.code` e `result.label`.

Exemplos de códigos: `won`, `lost`, `completed`, `incomplete`, `blocked`, `cleared`, `intercepted`, `on_target`, `off_target`, `successful`, `unsuccessful`, `inconclusive`.

### 4. Ponto a desenvolver exige evidência

Um item sem `evidence_event_ids` não pode permanecer como `development_points` ou `collective_vulnerabilities`.

Ele é movido automaticamente para `non_evaluable_items`.

Isso impede que falta de informação seja tratada como deficiência do atleta/equipe.

### 5. Linguagem mais disciplinada

O prompt exige linguagem de observação pontual quando existe apenas uma evidência. Linguagem de padrão/recorrência só deve aparecer com múltiplas evidências independentes.

### 6. Melhores momentos sem nota automática

Em `highlights`, `score_0_to_10` é forçado para `null`, independentemente do que o modelo tentar retornar.

O material mostra capacidades observadas, mas não prova consistência, frequência real ou ausência de erros.

### 7. Contexto observado automático

O JSON consolida equipes, adversários, competições e camisas vistos nos lances, com número de menções e confiança média.

O contexto observado fica separado do contexto informado pelo usuário.

## Contrato universal `scout.analysis.v3`

O V3 separa explicitamente:

- `evidence`: fatos/evidências do vídeo;
- `ai_assessment`: leitura sugerida pela IA;
- `human_assessment`: opinião profissional;
- `review`: decisões de confirmar/ajustar/rejeitar;
- `final_assessment`: decisão oficial;
- `audit`: origem e rastreabilidade;
- `report`: metadados do relatório.

Use `scout_analysis_v3.schema.json` para validar importações no Audit Scout ou em outro cliente.

Leia `AUDIT_SCOUT_INTEGRACAO.md` para o fluxo recomendado de importação, duas opiniões e relatório oficial.

## PDF preliminar

A V2.3 gera automaticamente `scout_report_draft.pdf`.

Ele é marcado como **RASCUNHO - REVISAO HUMANA PENDENTE** e apresenta:

- identificação/contexto;
- leitura assistida por IA;
- pontos fortes/desenvolvimento sustentados por evidências;
- itens não avaliáveis;
- evidências com timestamps e confianças separadas;
- seção de avaliação humana;
- status de conclusão final;
- auditoria.

O PDF oficial deve ser gerado pelo Audit Scout somente após revisão humana.

## Converter análises V2 já concluídas

Não é necessário reprocessar um vídeo só para obter o novo contrato/PDF.

Execute:

`CONVERTER_ANALISE_V2_PARA_AUDIT_SCOUT.cmd`

Selecione um `scout_analysis_v2.json` existente. O programa criará na mesma pasta:

- `scout_analysis_v3.json`
- `scout_report_draft.pdf`

## Arquivos do projeto de análise

- `manifest.json`
- `raw_chunks/`
- `chunks/`
- `evidence.json`
- `scout_analysis_v2.json`
- `scout_analysis_v3.json`
- `scout_report_draft.pdf`

## Iniciar no Windows

1. Extraia o ZIP.
2. Dê duplo clique em `START_SCOUT_ANALYZER_V2.cmd`.
3. Na primeira execução da V2.3.0, aguarde a atualização das dependências (inclui ReportLab para o PDF).
4. Em Configuração, valide sua chave Gemini/modelo.

O ambiente fica em `%LOCALAPPDATA%\ScoutVideoAnalyzerLocalV2`.

## Diagnóstico

Execute `DIAGNOSTICO_SCOUT.cmd`.

Logs ficam em:

`%LOCALAPPDATA%\ScoutVideoAnalyzerLocalV2\logs`

A V2.3.0 usa `start_v230.log`.

## Testes locais incluídos

`TESTE_ESTRUTURA.py` valida:

- blocos de jogo completo;
- identificação informada x observada;
- confianças separadas;
- resultado objetivo;
- contexto observado;
- regra de desenvolvimento sem evidência;
- nota nula em highlights;
- contrato `scout.analysis.v3`;
- geração de PDF.

## Criar EXE

Após homologação, execute `CRIAR_EXE_WINDOWS.cmd`. O build continua fora do OneDrive.
