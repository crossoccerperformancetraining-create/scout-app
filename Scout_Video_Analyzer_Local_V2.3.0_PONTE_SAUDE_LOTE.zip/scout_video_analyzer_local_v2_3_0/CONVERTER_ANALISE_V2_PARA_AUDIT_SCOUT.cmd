@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Converter Analise V2 para Audit Scout V3
call "%~dp0_PREPARAR_AMBIENTE.cmd"
if errorlevel 1 exit /b %errorlevel%
set "PY=%LOCALAPPDATA%\ScoutVideoAnalyzerLocalV2\venv\Scripts\python.exe"
"%PY%" "%~dp0convert_existing_v2.py"
endlocal
