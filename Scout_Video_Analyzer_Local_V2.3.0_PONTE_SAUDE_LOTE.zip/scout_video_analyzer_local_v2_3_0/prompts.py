from __future__ import annotations

import json
from typing import Any


ATHLETE_PHASES = [
    "ofensiva",
    "defensiva",
    "transicao_ofensiva",
    "transicao_defensiva",
    "bola_parada",
    "sem_bola",
    "outra",
]
TEAM_PHASES = [
    "construcao",
    "progressao",
    "ultimo_terco",
    "pressao_alta",
    "bloco_medio",
    "bloco_baixo",
    "transicao_ofensiva",
    "transicao_defensiva",
    "bola_parada_ofensiva",
    "bola_parada_defensiva",
    "outra",
]


def _fmt_list(values: Any) -> str:
    if not isinstance(values, list):
        return "não informado"
    clean = [str(x).strip() for x in values if str(x).strip()]
    return "; ".join(clean) if clean else "não informado"


def _fmt_roster(values: Any) -> str:
    if not isinstance(values, list) or not values:
        return "não informado"
    parts = []
    for item in values[:30]:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        pid = str(item.get("player_id") or "").strip()
        pos = str(item.get("position") or "").strip()
        if name or pid:
            label = name or pid
            if pos:
                label += f" ({pos})"
            if pid:
                label += f" [id={pid}]"
            parts.append(label)
    return "; ".join(parts) if parts else "não informado"


def chunk_prompt(context: dict[str, Any], start_s: float, end_s: float | None) -> str:
    target = context["target_type"]
    material = context["material_type"]
    start_label = _hms(start_s)
    end_label = _hms(end_s) if end_s is not None else "fim do vídeo"

    if material == "highlights":
        limitation = (
            "Este material é MELHORES MOMENTOS / AMOSTRA SELECIONADA. Pode reunir vários jogos e, no caso de atleta, vários clubes, "
            "uniformes e números. Não conclua consistência, frequência real, ausência de erros nem rendimento de 90 minutos."
        )
    else:
        limitation = (
            "Este material é JOGO COMPLETO ou cobertura extensa. Ainda assim, registre limitações de câmera, oclusão e identificação."
        )

    if target == "athlete":
        contract = {
            "athlete_seen": True,
            "identification_confidence": 0.0,
            "observed_athlete_name": None,
            "observed_athlete_aliases": [],
            "identification_cues": [],
            "events": [
                {
                    "offset_seconds": 0.0,
                    "phase": "defensiva",
                    "category": "duelo_aereo",
                    "action": "descrição curta da ação",
                    "outcome": "positivo|negativo|neutro|inconclusivo",
                    "result_code": "successful|unsuccessful|won|lost|completed|incomplete|intercepted|blocked|cleared|retained|lost_possession|on_target|off_target|goal|neutral|inconclusive|other",
                    "result_label": "resultado objetivo e curto da ação",
                    "description": "descrição factual",
                    "tactical_note": "leitura tática opcional e sustentada",
                    "identification_confidence": 0.0,
                    "action_confidence": 0.0,
                    "context_confidence": 0.0,
                    "confidence": 0.0,
                    "observed_team": None,
                    "observed_team_confidence": 0.0,
                    "observed_shirt_number": None,
                    "observed_shirt_number_confidence": 0.0,
                    "observed_opponent": None,
                    "observed_opponent_confidence": 0.0,
                    "observed_competition": None,
                    "observed_competition_confidence": 0.0,
                    "identification_cues": [],
                }
            ],
            "limitations": [],
        }

        if material == "highlights":
            subject = f"""
ATLETA-ALVO — COMPILADO / MELHORES MOMENTOS
- Nome: {context.get('athlete_name') or 'não informado'}
- Posição: {context.get('position') or 'não informada'}
- Equipe(s) informada(s), se houver: {_fmt_list(context.get('teams_context'))}
- Adversário(s) informado(s), se houver: {_fmt_list(context.get('opponents_context'))}
- Competição(ões) informada(s), se houver: {_fmt_list(context.get('competitions_context'))}
- Período/temporada informado, se houver: {context.get('period') or 'não informado'}
- Observações do usuário: {context.get('notes') or 'nenhuma'}
""".strip()
            instructions = f"""
Procure apenas ações que possam ser atribuídas com segurança suficiente ao atleta-alvo.
O atleta pode aparecer em EQUIPES, UNIFORMES e NÚMEROS DE CAMISA DIFERENTES ao longo do vídeo. Não exija continuidade de clube ou camisa entre clipes.
Quando houver grafismo claramente associado ao atleta (círculo, seta, contorno, spotlight, zoom, freeze-frame ou destaque semelhante), use-o como pista forte de identificação, mas confira se ele realmente aponta para o atleta-alvo naquele lance.
Não trate qualquer grafismo como prova automática: combine-o com posição, continuidade espacial, contexto do lance e outras pistas visuais.
Se o atleta não puder ser identificado com confiança suficiente em um trecho, não atribua a ação a ele.
Se equipe, camisa, adversário ou competição forem visíveis, registre-os nos campos observed_*; se não forem, use null — nunca invente.
Registre eventos relevantes para a posição informada. Fases permitidas: {', '.join(ATHLETE_PHASES)}.
""".strip()
        else:
            subject = f"""
ATLETA-ALVO — JOGO COMPLETO
- Nome: {context.get('athlete_name') or 'não informado'}
- Equipe: {context.get('team') or 'não informada'}
- Posição: {context.get('position') or 'não informada'}
- Camisa esperada: {context.get('shirt_number') or 'não informada'}
- Adversário: {context.get('opponent') or 'não informado'}
- Competição: {context.get('competition') or 'não informada'}
- Data: {context.get('match_date') or 'não informada'}
""".strip()
            instructions = f"""
Procure apenas ações que possam ser atribuídas com segurança suficiente ao atleta-alvo.
Use camisa, equipe, posição, uniforme, continuidade espacial e contexto da partida para identificação. Não invente identidade.
Grafismos visuais, quando presentes, podem reforçar a identificação, mas não substituem a conferência do contexto.
Se houver contexto observado diferente do esperado, registre nos campos observed_* e reduza a confiança se houver ambiguidade.
Registre eventos relevantes para a posição informada. Fases permitidas: {', '.join(ATHLETE_PHASES)}.
""".strip()
    else:
        contract = {
            "team_seen": True,
            "team_identification_confidence": 0.0,
            "observed_team_name": None,
            "identification_cues": [],
            "events": [
                {
                    "offset_seconds": 0.0,
                    "phase": "construcao",
                    "category": "saida_de_bola",
                    "pattern": "padrão coletivo observado",
                    "outcome": "positivo|negativo|neutro|inconclusivo",
                    "result_code": "successful|unsuccessful|completed|incomplete|retained|lost_possession|neutral|inconclusive|other",
                    "result_label": "resultado objetivo e curto do comportamento",
                    "description": "descrição factual coletiva",
                    "tactical_note": "leitura tática sustentada",
                    "identification_confidence": 0.0,
                    "action_confidence": 0.0,
                    "context_confidence": 0.0,
                    "confidence": 0.0,
                    "observed_opponent": None,
                    "observed_opponent_confidence": 0.0,
                    "observed_competition": None,
                    "observed_competition_confidence": 0.0,
                    "observed_player_name": None,
                    "observed_player_id": None,
                    "observed_player_position": None,
                    "observed_player_confidence": 0.0,
                }
            ],
            "limitations": [],
        }

        if material == "highlights":
            subject = f"""
EQUIPE-ALVO — COMPILADO / MELHORES MOMENTOS
- Equipe: {context.get('team') or 'não informada'}
- Adversário(s) informado(s), se houver: {_fmt_list(context.get('opponents_context'))}
- Competição(ões) informada(s), se houver: {_fmt_list(context.get('competitions_context'))}
- Período/temporada informado, se houver: {context.get('period') or 'não informado'}
- Observações do usuário: {context.get('notes') or 'nenhuma'}
- Elenco informado pelo Scout, se houver: {_fmt_roster(context.get('team_roster'))}
""".strip()
            instructions = f"""
Analise comportamentos COLETIVOS da equipe-alvo. O foco é coletivo, mas quando um evento puder ser atribuído com segurança a um atleta do elenco informado, registre observed_player_name/observed_player_id/observed_player_position e a confiança correspondente. Não force identificação individual.
O compilado pode reunir jogos contra adversários diferentes e competições diferentes. Não assuma que todo trecho pertence ao mesmo jogo.
Se adversário ou competição forem visíveis, registre nos campos observed_*; se não forem, use null — nunca invente.
Procure construção, progressão, último terço, pressão, blocos defensivos, compactação, transições e bolas paradas.
Fases permitidas: {', '.join(TEAM_PHASES)}.
""".strip()
        else:
            subject = f"""
EQUIPE-ALVO — JOGO COMPLETO
- Equipe: {context.get('team') or 'não informada'}
- Adversário: {context.get('opponent') or 'não informado'}
- Competição: {context.get('competition') or 'não informada'}
- Data: {context.get('match_date') or 'não informada'}
- Elenco informado pelo Scout, se houver: {_fmt_roster(context.get('team_roster'))}
""".strip()
            instructions = f"""
Analise comportamentos COLETIVOS da equipe-alvo. O foco é coletivo, mas quando um evento puder ser atribuído com segurança a um atleta do elenco informado, registre observed_player_name/observed_player_id/observed_player_position e a confiança correspondente. Não force identificação individual.
Procure construção, progressão, último terço, pressão, blocos defensivos, compactação, transições e bolas paradas.
Fases permitidas: {', '.join(TEAM_PHASES)}.
""".strip()

    max_offset_rule = (
        " Deve ficar entre 0 e " + str(max(1, int(end_s - start_s))) + "."
        if end_s is not None
        else " Use o deslocamento real dentro do clipe."
    )

    return f"""
Você é um analista de desempenho de futebol. Analise SOMENTE o trecho de vídeo apresentado.
O trecho corresponde aproximadamente a {start_label}–{end_label} do vídeo original.

{subject}

REGRAS
1. {limitation}
2. O scout/analista humano é o decisor; você apenas localiza evidências e sugere leitura.
3. Não invente ações, estatísticas, intenção, identidade ou contexto.
4. "offset_seconds" é o número de segundos A PARTIR DO INÍCIO DESTE TRECHO, não do vídeo inteiro.{max_offset_rule}
5. Separe confiança de IDENTIFICAÇÃO, da AÇÃO e do CONTEXTO. Não use um único número para esconder incertezas diferentes.
6. Só registre eventos quando a ação tiver action_confidence >= 0.55; para atleta, identification_confidence também deve ser >= 0.55.
7. O resultado deve ser objetivo. Prefira result_code/result_label (ex.: won/lost, completed/incomplete, cleared, blocked) em vez de apenas "positivo".
8. Se nome/alias do atleta ou nome da equipe aparecer em cartão, grafismo ou placar, registre observed_*_name sem substituir o nome informado pelo usuário.
9. Use português do Brasil, técnico e conciso.
10. {instructions}
11. Responda SOMENTE JSON válido, sem markdown e sem texto adicional.

CONTRATO JSON DESTA ETAPA
{json.dumps(contract, ensure_ascii=False, indent=2)}
""".strip()


def synthesis_prompt(context: dict[str, Any], events: list[dict[str, Any]], limitations: list[str]) -> str:
    target = context["target_type"]
    material = context["material_type"]
    model_game = (context.get("model_game") or "").strip()

    if material == "highlights":
        sample_rule = (
            "O material é MELHORES MOMENTOS / AMOSTRA SELECIONADA. Nunca conclua consistência ao longo de 90 minutos, frequência real, "
            "ausência de erros ou superioridade estatística. Descreva capacidades observadas e limitações da amostra."
        )
    else:
        sample_rule = "O material é JOGO COMPLETO/cobertura extensa; ainda assim respeite limitações registradas."

    compact_events = []
    for e in events:
        item = {
            "event_id": e.get("event_id"),
            "timestamp": e.get("video_timestamp"),
            "phase": e.get("phase"),
            "category": e.get("category"),
            "outcome": e.get("outcome"),
            "description": e.get("description"),
            "tactical_note": e.get("tactical_note"),
            "confidence": e.get("confidence"),
            "confidence_breakdown": e.get("confidence_breakdown"),
            "result": e.get("result"),
        }
        for key in (
            "observed_team",
            "observed_shirt_number",
            "observed_opponent",
            "observed_competition",
            "observed_player_name",
            "observed_player_id",
            "observed_player_position",
            "observed_player_confidence",
            "identification_cues",
        ):
            if e.get(key):
                item[key] = e.get(key)
        if target == "team":
            item["pattern"] = e.get("pattern")
        else:
            item["action"] = e.get("action")
        compact_events.append(item)

    if target == "athlete":
        contract = {
            "strengths": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
            "development_points": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
            "tactical_behavior": {
                "with_ball": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
                "without_ball": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
                "transitions": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
                "positional_discipline": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
            },
            "model_game_comparison": [
                {
                    "criterion": "",
                    "status": "aderente|parcialmente_aderente|nao_aderente|nao_avaliavel",
                    "analysis": "",
                    "confidence": 0.0,
                    "evidence_event_ids": [],
                }
            ],
            "non_evaluable_items": [],
            "suggested_rating": {
                "score_0_to_10": None,
                "confidence": 0.0,
                "rationale": "",
                "human_review_required": True,
            },
            "warnings": [],
        }
        if material == "highlights":
            target_text = (
                f"Atleta {context.get('athlete_name')} ({context.get('position')}), em compilado de melhores momentos. "
                f"Equipes informadas: {_fmt_list(context.get('teams_context'))}. "
                f"Competições informadas: {_fmt_list(context.get('competitions_context'))}."
            )
        else:
            target_text = (
                f"Atleta {context.get('athlete_name')} ({context.get('position')}, camisa {context.get('shirt_number')}) "
                f"da equipe {context.get('team')}"
            )
    else:
        contract = {
            "collective_strengths": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
            "collective_vulnerabilities": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
            "phases": {
                "build_up": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
                "progression": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
                "final_third": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
                "defensive_organization": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
                "transitions": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
                "set_pieces": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
            },
            "key_patterns": [{"title": "", "analysis": "", "confidence": 0.0, "evidence_event_ids": []}],
            "model_game_comparison": [
                {
                    "criterion": "",
                    "status": "aderente|parcialmente_aderente|nao_aderente|nao_avaliavel",
                    "analysis": "",
                    "confidence": 0.0,
                    "evidence_event_ids": [],
                }
            ],
            "non_evaluable_items": [],
            "warnings": [],
        }
        if material == "highlights":
            target_text = (
                f"Equipe {context.get('team')} em compilado de melhores momentos. "
                f"Adversários informados: {_fmt_list(context.get('opponents_context'))}. "
                f"Competições informadas: {_fmt_list(context.get('competitions_context'))}."
            )
        else:
            target_text = f"Equipe {context.get('team')} contra {context.get('opponent')}"

    model_block = (
        model_game
        if model_game
        else "Nenhum Modelo de Jogo foi fornecido. Não invente critérios; devolva model_game_comparison=[] ou marque não avaliável."
    )

    return f"""
Você é um analista de desempenho de futebol. Agora NÃO há vídeo: use exclusivamente as evidências estruturadas abaixo.
Produza uma síntese para revisão humana sobre: {target_text}.

REGRAS
1. {sample_rule}
2. Não crie fatos novos. Toda conclusão em strengths, development_points, tactical_behavior, collective_strengths, collective_vulnerabilities, phases ou key_patterns DEVE citar pelo menos um ID existente em evidence_event_ids.
3. Um item sem evidência não é "ponto a desenvolver" nem "vulnerabilidade": mova-o para non_evaluable_items.
4. Com uma única evidência, use linguagem de observação pontual ("apresentou evidência de..."), não de característica recorrente. Só use linguagem de padrão/recorrência quando houver múltiplas evidências independentes.
5. Não use uma evidência com baixa confiança de identificação como base única de uma conclusão forte, mesmo que a ação esteja clara.
6. Ausência de evento não prova incapacidade nem falha.
7. Quando não houver base suficiente, registre em non_evaluable_items.
8. Nota, quando houver, é apenas sugerida; human_review_required=true. Em melhores momentos, use SEMPRE score_0_to_10=null.
9. Use português do Brasil, técnico, conciso e útil a scout/analista/treinador.
10. Se os eventos vierem de equipes/adversários/competições diferentes, preserve essa diversidade; não transforme o compilado em uma única partida fictícia.
11. Responda SOMENTE JSON válido.

MODELO DE JOGO
{model_block}

LIMITAÇÕES ACUMULADAS
{json.dumps(limitations, ensure_ascii=False)}

EVIDÊNCIAS
{json.dumps(compact_events, ensure_ascii=False)}

CONTRATO JSON
{json.dumps(contract, ensure_ascii=False, indent=2)}
""".strip()


def _hms(seconds: float) -> str:
    total = max(0, int(seconds))
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"
