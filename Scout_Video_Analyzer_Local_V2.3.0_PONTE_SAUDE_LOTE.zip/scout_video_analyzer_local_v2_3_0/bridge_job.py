from __future__ import annotations

from typing import Any


def _clean(value: Any) -> str:
    return str(value or "").strip()


def parse_scout_job(job: dict[str, Any]) -> dict[str, Any]:
    """Normalize a Scout Intelligence bridge job into Analyzer form values.

    Accepted schema: scout.analyzer.job.v1. The function intentionally does not
    trust the job to make sporting conclusions; it only pre-fills context/source.
    """
    if not isinstance(job, dict) or _clean(job.get("schema_version")) != "scout.analyzer.job.v1":
        raise ValueError("Use uma tarefa scout.analyzer.job.v1 exportada pelo Scout Intelligence V74.")

    target = _clean(job.get("analysis_target") or (job.get("subject") or {}).get("type")).lower()
    if target not in {"athlete", "team"}:
        raise ValueError("A tarefa precisa informar analysis_target athlete ou team.")

    raw_material = _clean(job.get("material_type") or (job.get("material") or {}).get("type")).lower().replace("-", "_")
    if raw_material in {"fullmatch", "full_match", "match", "game", "jogo_completo"}:
        material = "full_match"
    elif raw_material in {"highlights", "highlight", "melhores_momentos"}:
        material = "highlights"
    else:
        raise ValueError("A tarefa precisa informar material full_match ou highlights.")

    subject = job.get("subject") if isinstance(job.get("subject"), dict) else {}
    athlete = subject.get("athlete") if isinstance(subject.get("athlete"), dict) else {}
    team_subject = subject.get("team") if isinstance(subject.get("team"), dict) else {}
    informed = ((job.get("context") or {}).get("informed") if isinstance(job.get("context"), dict) else {}) or {}
    material_obj = job.get("material") if isinstance(job.get("material"), dict) else {}
    source = material_obj.get("source") if isinstance(material_obj.get("source"), dict) else {}
    ref = _clean(source.get("reference"))
    source_type_raw = _clean(source.get("type")).lower()

    if source_type_raw in {"local_file", "mp4", "file"}:
        source_type = "mp4"
        source_warning = "Selecione o MP4 local no Analyzer antes de iniciar."
    else:
        source_type = "youtube"
        source_warning = ""
        if ref and "youtube.com/" not in ref and "youtu.be/" not in ref:
            source_warning = "A referência não parece ser YouTube. O Analyzer V2.3 processa URL pública do YouTube ou MP4 local autorizado."

    fields = {
        "athlete_name": _clean(athlete.get("name_informed") or athlete.get("name")),
        "position": _clean(athlete.get("position")),
        "shirt_number": _clean(athlete.get("shirt_number_informed") or athlete.get("shirt_number")),
        "team": _clean(informed.get("team") or athlete.get("team_informed") or team_subject.get("name_informed") or team_subject.get("name")),
        "opponent": _clean(informed.get("opponent")),
        "competition": _clean(informed.get("competition")),
        "match_date": _clean(informed.get("date")),
        "period": _clean(informed.get("period")),
        "notes": _clean(informed.get("notes")),
    }

    roster_raw = informed.get("roster") if isinstance(informed.get("roster"), list) else job.get("roster") if isinstance(job.get("roster"), list) else []
    roster = []
    for item in roster_raw:
        if not isinstance(item, dict):
            continue
        pid = _clean(item.get("player_id") or item.get("playerId") or item.get("id"))
        name = _clean(item.get("name") or item.get("player_name"))
        if pid or name:
            roster.append({"player_id": pid or None, "name": name or None, "position": _clean(item.get("position")) or None})

    integration = {
        "source": "scout-intelligence",
        "job_schema": "scout.analyzer.job.v1",
        "job_id": _clean(job.get("job_id")) or None,
        "created_at": _clean(job.get("created_at")) or None,
        "linked_player_id": _clean(athlete.get("player_id")) or None,
        "linked_match_id": _clean(informed.get("match_id")) or None,
        "output_contract": job.get("output_contract") if isinstance(job.get("output_contract"), dict) else {},
        "constraints": job.get("constraints") if isinstance(job.get("constraints"), dict) else {},
        "roster": roster,
    }

    return {
        "target_type": target,
        "material_type": material,
        "fields": fields,
        "source_type": source_type,
        "source_reference": ref,
        "source_warning": source_warning,
        "model_game": _clean(job.get("model_game") or informed.get("model_game")),
        "integration": integration,
    }
