from __future__ import annotations

import json
import time
import urllib.error
import urllib.request

from local_bridge import load_result, mark_state, publish_result, read_state, start_bridge_server

server, thread, token = start_bridge_server(analyzer_version="2.3.0", port=8766)
base = "http://127.0.0.1:8766"
try:
    health = json.loads(urllib.request.urlopen(base + "/health", timeout=2).read().decode("utf-8"))
    assert health["ok"] is True
    assert health["analyzer_version"] == "2.3.0"
    job = {
        "schema_version": "scout.analyzer.job.v1",
        "job_id": "JOB-TESTE-PONTE",
        "analysis_target": "athlete",
        "material_type": "highlights",
        "subject": {"type": "athlete", "athlete": {"name_informed": "Teste", "position": "ZAG"}},
        "material": {"type": "highlights", "source": {"type": "youtube", "reference": "https://youtu.be/test"}},
        "context": {"informed": {}},
    }
    req = urllib.request.Request(
        base + "/jobs",
        data=json.dumps(job).encode("utf-8"),
        method="POST",
        headers={"Content-Type": "application/json", "X-Scout-Bridge-Token": token},
    )
    created = json.loads(urllib.request.urlopen(req, timeout=2).read().decode("utf-8"))
    assert created["job_id"] == "JOB-TESTE-PONTE"
    assert read_state("JOB-TESTE-PONTE")["status"] == "queued"
    result = {"schema_version": "scout.analysis.v3", "analysis_id": "TESTE", "evidence": []}
    publish_result("JOB-TESTE-PONTE", result)
    req2 = urllib.request.Request(base + "/results/JOB-TESTE-PONTE", headers={"X-Scout-Bridge-Token": token})
    got = json.loads(urllib.request.urlopen(req2, timeout=2).read().decode("utf-8"))
    assert got["ok"] is True and got["result"]["schema_version"] == "scout.analysis.v3"
    print("TESTE_PONTE_LOCAL V2.3.0: OK")
finally:
    server.shutdown(); server.server_close()
