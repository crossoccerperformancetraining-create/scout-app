from __future__ import annotations

import json
import math
import os
import uuid
from difflib import SequenceMatcher
from pathlib import Path
from typing import Callable, Any

from prompts import chunk_prompt, synthesis_prompt
from utils import read_json, write_json, seconds_to_hms, utc_now_iso, slugify, parse_duration_seconds
from audit_contract import build_observed_context, build_analysis_v3
from report_pdf import generate_report_pdf

StatusCallback = Callable[[str, float | None], None] | None

DEFAULT_CHUNK_SECONDS = 8 * 60
DEFAULT_OVERLAP_SECONDS = 15


def _status(cb: StatusCallback, text: str, progress: float | None = None) -> None:
    if cb:
        cb(text, progress)


def create_project(parent_dir: str, context: dict[str, Any]) -> Path:
    label = context.get("athlete_name") if context.get("target_type") == "athlete" else context.get("team")
    stamp = utc_now_iso().replace(":", "").replace("-", "").replace("T", "_").replace("Z", "")
    project = Path(parent_dir) / f"ScoutV2_{slugify(str(label or 'analise'))}_{stamp}"
    (project / "chunks").mkdir(parents=True, exist_ok=False)
    (project / "raw_chunks").mkdir(parents=True, exist_ok=True)
    manifest = {
        "schema_version": "scout.video_analysis.project.v2",
        "project_id": str(uuid.uuid4()),
        "created_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
        "status": "created",
        "context": context,
        "source_runtime": {},
        "chunking": {
            "chunk_seconds": DEFAULT_CHUNK_SECONDS,
            "overlap_seconds": DEFAULT_OVERLAP_SECONDS,
            "windows": [],
        },
        "completed_chunks": [],
        "last_error": None,
        "final_json": None,
    }
    write_json(project / "manifest.json", manifest)
    return project


def run_project(*, project_dir: str | Path, api_key: str, model: str,
                status_cb: StatusCallback = None) -> Path:
    from gemini_client import analyze_video_window, upload_video, delete_uploaded_file, synthesize_text_json
    project = Path(project_dir)
    manifest_path = project / "manifest.json"
    manifest = read_json(manifest_path)
    context = manifest["context"]
    manifest["status"] = "running"
    manifest["updated_at"] = utc_now_iso()
    manifest["last_error"] = None
    write_json(manifest_path, manifest)

    source = context["source"]
    uploaded_name: str | None = None
    file_uri: str
    mime_type: str | None = None
    duration_s: float | None = _duration_from_context(context)

    try:
        if source["type"] == "mp4":
            path = source["path"]
            if not Path(path).is_file():
                raise FileNotFoundError(f"O MP4 salvo no projeto não existe mais: {path}")
            uploaded, detected_duration = upload_video(api_key, path, lambda msg: _status(status_cb, msg, None))
            uploaded_name = getattr(uploaded, "name", None)
            file_uri = getattr(uploaded, "uri", None)
            mime_type = getattr(uploaded, "mime_type", None) or "video/mp4"
            if not file_uri:
                raise RuntimeError("A Files API não retornou URI do vídeo.")
            if detected_duration:
                duration_s = detected_duration
        else:
            file_uri = source["url"]

        windows = manifest.get("chunking", {}).get("windows") or []
        if not windows:
            windows = _build_windows(context, duration_s)
            manifest["chunking"]["windows"] = windows
            manifest["source_runtime"] = {
                "duration_seconds": duration_s,
                "file_uri_kind": "files_api" if source["type"] == "mp4" else "youtube_public",
            }
            write_json(manifest_path, manifest)

        completed = set(int(x) for x in manifest.get("completed_chunks", []))
        total = len(windows)
        _status(status_cb, f"Projeto com {total} bloco(s). Retomando do ponto salvo...", 0.02)

        for i, window in enumerate(windows, start=1):
            if i in completed and (project / "chunks" / f"chunk_{i:03d}.json").exists():
                continue
            start_s = window.get("start_s")
            end_s = window.get("end_s")
            label = f"Bloco {i}/{total}"
            _status(status_cb, f"{label}: {seconds_to_hms(start_s or 0)}–{seconds_to_hms(end_s or 0) if end_s is not None else 'fim'}", 0.05 + 0.70 * ((i-1) / max(1, total)))
            prompt = chunk_prompt(context, float(start_s or 0), None if end_s is None else float(end_s))
            raw = analyze_video_window(
                api_key=api_key,
                model=model,
                file_uri=file_uri,
                mime_type=mime_type,
                prompt=prompt,
                start_s=start_s,
                end_s=end_s,
                status_cb=lambda msg, lab=label: _status(status_cb, f"{lab}: {msg}", None),
            )
            write_json(project / "raw_chunks" / f"chunk_{i:03d}_raw.json", raw)
            normalized = _normalize_chunk(raw, context, i, float(start_s or 0), end_s)
            write_json(project / "chunks" / f"chunk_{i:03d}.json", normalized)
            completed.add(i)
            manifest = read_json(manifest_path)
            manifest["completed_chunks"] = sorted(completed)
            manifest["updated_at"] = utc_now_iso()
            manifest["status"] = "running"
            write_json(manifest_path, manifest)

        _status(status_cb, "Consolidando evidências dos blocos...", 0.78)
        chunks = [read_json(project / "chunks" / f"chunk_{i:03d}.json") for i in range(1, total + 1)]
        events, limitations, identification = _merge_chunks(chunks, context)
        observed_context = build_observed_context(events)
        evidence_payload = {
            "events": events,
            "limitations": limitations,
            "identification": identification,
            "observed_context": observed_context,
        }
        write_json(project / "evidence.json", evidence_payload)

        synthesis = None
        synthesis_error = None
        try:
            _status(status_cb, "Evidências prontas. Gerando síntese sem reenviar o vídeo...", 0.84)
            synthesis = synthesize_text_json(
                api_key=api_key,
                model=model,
                prompt=synthesis_prompt(context, events, limitations),
                status_cb=lambda msg: _status(status_cb, msg, None),
            )
            synthesis = _normalize_synthesis(synthesis, context, {e["event_id"] for e in events})
        except Exception as exc:
            # Important V2 design: evidence extraction is not discarded if synthesis fails.
            synthesis_error = f"{type(exc).__name__}: {exc}"
            synthesis = _empty_synthesis(context)
            synthesis["warnings"].append("A síntese automática falhou; as evidências foram preservadas e podem ser revisadas/reprocessadas.")

        final = _build_final_json(context, model, windows, events, limitations, identification, observed_context, synthesis, synthesis_error)
        final_path = project / "scout_analysis_v2.json"
        write_json(final_path, final)

        # Platform-neutral contract for Audit Scout and other clients.
        v3 = build_analysis_v3(final)
        v3_path = project / "scout_analysis_v3.json"
        write_json(v3_path, v3)

        report_path = project / "scout_report_draft.pdf"
        report_error = None
        try:
            _status(status_cb, "Gerando relatório PDF preliminar...", 0.96)
            generate_report_pdf(v3, report_path)
        except Exception as exc:
            report_error = f"{type(exc).__name__}: {exc}"
            v3["report"]["status"] = "draft_pdf_generation_error"
            v3["report"]["error"] = report_error
            write_json(v3_path, v3)

        manifest = read_json(manifest_path)
        manifest["status"] = "completed" if synthesis_error is None else "completed_with_synthesis_warning"
        manifest["updated_at"] = utc_now_iso()
        manifest["final_json"] = str(final_path)
        manifest["universal_json"] = str(v3_path)
        manifest["report_pdf"] = str(report_path) if report_error is None else None
        manifest["report_error"] = report_error
        manifest["last_error"] = synthesis_error
        write_json(manifest_path, manifest)
        _status(status_cb, "Análise concluída. JSON universal V3 e relatório preliminar prontos para revisão humana.", 1.0)
        return v3_path
    except Exception as exc:
        manifest = read_json(manifest_path)
        manifest["status"] = "paused_error"
        manifest["updated_at"] = utc_now_iso()
        manifest["last_error"] = f"{type(exc).__name__}: {exc}"
        write_json(manifest_path, manifest)
        raise
    finally:
        if uploaded_name:
            delete_uploaded_file(api_key, uploaded_name)


def _duration_from_context(context: dict[str, Any]) -> float | None:
    value = context.get("duration_minutes")
    try:
        if value is not None and float(value) > 0:
            return float(value) * 60.0
    except Exception:
        pass
    return None


def _build_windows(context: dict[str, Any], duration_s: float | None) -> list[dict[str, float | None]]:
    material = context["material_type"]
    if duration_s is None:
        if context["source"]["type"] == "youtube" and material == "highlights":
            # Small highlight clips may be safely processed as one request without clipping.
            return [{"start_s": None, "end_s": None}]
        raise ValueError("Não foi possível determinar a duração do vídeo. Informe a duração total em minutos e continue a análise.")

    chunk_s = DEFAULT_CHUNK_SECONDS if material == "full_match" else 10 * 60
    overlap = DEFAULT_OVERLAP_SECONDS if material == "full_match" else 10
    if duration_s <= chunk_s:
        return [{"start_s": 0.0, "end_s": float(duration_s)}]
    windows: list[dict[str, float]] = []
    start = 0.0
    while start < duration_s - 0.5:
        end = min(start + chunk_s, duration_s)
        windows.append({"start_s": round(start, 3), "end_s": round(end, 3)})
        if end >= duration_s:
            break
        start = max(start + 1.0, end - overlap)
    return windows


def _normalize_chunk(raw: dict[str, Any], context: dict[str, Any], index: int,
                     start_s: float, end_s: float | None) -> dict[str, Any]:
    events_raw = raw.get("events") if isinstance(raw.get("events"), list) else []
    events: list[dict[str, Any]] = []
    max_offset = None if end_s is None else max(0.0, float(end_s) - start_s)
    top_ident_conf = _clamp(raw.get("identification_confidence" if context["target_type"] == "athlete" else "team_identification_confidence", 0.0))

    for pos, e in enumerate(events_raw, start=1):
        if not isinstance(e, dict):
            continue

        action_conf = _clamp(e.get("action_confidence", e.get("confidence", 0.0)))
        identification_conf = _clamp(e.get("identification_confidence", top_ident_conf))
        context_conf = _clamp(e.get("context_confidence", 0.0))
        if action_conf < 0.55:
            continue
        if context["target_type"] == "athlete" and identification_conf < 0.55:
            # We prefer losing one ambiguous clip over attributing it to the wrong athlete.
            continue
        overall_conf = min(action_conf, identification_conf) if context["target_type"] == "athlete" else action_conf

        raw_offset = e.get("offset_seconds")
        try:
            offset = float(raw_offset)
        except Exception:
            parsed = parse_duration_seconds(e.get("clip_timestamp") or e.get("timestamp") or e.get("video_timestamp"))
            offset = float(parsed or 0.0)
        offset = max(0.0, offset)
        if max_offset is not None:
            offset = min(max_offset, offset)
        global_s = start_s + offset

        result_code, result_label = _normalize_result(e)
        event = {
            "source_chunk": index,
            "source_event_index": pos,
            "video_time_seconds": round(global_s, 2),
            "video_timestamp": seconds_to_hms(global_s),
            "phase": str(e.get("phase") or "outra"),
            "category": str(e.get("category") or "outra"),
            # Legacy compatibility fields:
            "outcome": _outcome(e.get("outcome")),
            "confidence": round(overall_conf, 3),
            # V2.1 quality fields:
            "result": {"code": result_code, "label": result_label},
            "result_code": result_code,
            "result_label": result_label,
            "confidence_breakdown": {
                "identification": round(identification_conf, 3),
                "action": round(action_conf, 3),
                "context": round(context_conf, 3),
                "overall": round(overall_conf, 3),
            },
            "description": str(e.get("description") or "").strip(),
            "tactical_note": _optional_text(e.get("tactical_note")),
        }
        if context["target_type"] == "athlete":
            event["action"] = str(e.get("action") or e.get("pattern") or "ação observada").strip()
        else:
            event["pattern"] = str(e.get("pattern") or e.get("action") or "padrão observado").strip()

        for key in ("observed_team", "observed_shirt_number", "observed_opponent", "observed_competition"):
            value = _optional_text(e.get(key))
            if value:
                event[key] = value
                event[f"{key}_confidence"] = _clamp(e.get(f"{key}_confidence", context_conf))
        if context["target_type"] == "team":
            player_name = _optional_text(e.get("observed_player_name"))
            player_id = _optional_text(e.get("observed_player_id"))
            player_position = _optional_text(e.get("observed_player_position"))
            if player_name or player_id:
                event["observed_player_name"] = player_name
                event["observed_player_id"] = player_id
                event["observed_player_position"] = player_position
                event["observed_player_confidence"] = _clamp(e.get("observed_player_confidence", identification_conf))
        cues = e.get("identification_cues")
        if isinstance(cues, list):
            clean_cues = [str(x).strip() for x in cues if str(x).strip()]
            if clean_cues:
                event["identification_cues"] = clean_cues[:12]

        if event["description"]:
            events.append(event)

    result = {
        "chunk_index": index,
        "start_s": start_s,
        "end_s": end_s,
        "events": events,
        "limitations": [str(x) for x in (raw.get("limitations") or []) if str(x).strip()],
        "raw_identification": {},
    }
    if context["target_type"] == "athlete":
        aliases = raw.get("observed_athlete_aliases") if isinstance(raw.get("observed_athlete_aliases"), list) else []
        result["raw_identification"] = {
            "seen": bool(raw.get("athlete_seen", False)),
            "confidence": top_ident_conf,
            "cues": [str(x) for x in (raw.get("identification_cues") or []) if str(x).strip()],
            "observed_name": _optional_text(raw.get("observed_athlete_name")),
            "observed_aliases": [str(x).strip() for x in aliases if str(x).strip()],
        }
    else:
        result["raw_identification"] = {
            "seen": bool(raw.get("team_seen", True)),
            "confidence": top_ident_conf,
            "cues": [str(x) for x in (raw.get("identification_cues") or []) if str(x).strip()],
            "observed_name": _optional_text(raw.get("observed_team_name")),
            "observed_aliases": [],
        }
    return result


def _merge_chunks(chunks: list[dict[str, Any]], context: dict[str, Any]):
    events: list[dict[str, Any]] = []
    limitations: list[str] = []
    ident_conf: list[float] = []
    ident_cues: list[str] = []
    observed_names: list[str] = []
    observed_aliases: list[str] = []
    seen_count = 0
    for ch in chunks:
        for lim in ch.get("limitations", []):
            if lim and lim not in limitations:
                limitations.append(lim)
        ident = ch.get("raw_identification") or {}
        if ident.get("seen"):
            seen_count += 1
        try:
            ident_conf.append(float(ident.get("confidence", 0.0)))
        except Exception:
            pass
        for cue in ident.get("cues") or []:
            if cue not in ident_cues:
                ident_cues.append(cue)
        observed_name = _optional_text(ident.get("observed_name"))
        if observed_name and observed_name not in observed_names:
            observed_names.append(observed_name)
        for alias in ident.get("observed_aliases") or []:
            alias = str(alias).strip()
            if alias and alias not in observed_aliases:
                observed_aliases.append(alias)
        for e in ch.get("events", []):
            if not _is_duplicate(e, events, context):
                events.append(e)

    events.sort(key=lambda x: float(x.get("video_time_seconds", 0.0)))
    for idx, e in enumerate(events, start=1):
        e["event_id"] = f"EVT-{idx:04d}"

    identification = {
        "identified_in_chunks": seen_count,
        "total_chunks": len(chunks),
        "confidence_mean": round(sum(ident_conf) / len(ident_conf), 3) if ident_conf else 0.0,
        "visual_cues": ident_cues[:30],
        "strategy": context.get("identification_strategy"),
        "observed_name": observed_names[0] if observed_names else None,
        "observed_aliases": observed_aliases[:20],
    }

    if context["material_type"] == "highlights":
        generic = (
            "Amostra selecionada (melhores momentos): não permite inferir consistência, frequência real nem ausência de erros "
            "ao longo de um jogo completo."
        )
        if generic not in limitations:
            limitations.insert(0, generic)
        if context["target_type"] == "athlete":
            multi = (
                "O compilado pode reunir equipes, uniformes e números de camisa diferentes. Grafismos visuais podem ajudar a identificar "
                "o atleta, mas não são tratados como prova automática de identidade."
            )
        else:
            multi = (
                "O compilado de equipe pode reunir jogos, adversários e competições diferentes; contexto não visível ou não informado "
                "permanece não identificável."
            )
        if multi not in limitations:
            limitations.insert(1, multi)
    return events, limitations, identification

def _is_duplicate(candidate: dict[str, Any], existing: list[dict[str, Any]], context: dict[str, Any]) -> bool:
    t = float(candidate.get("video_time_seconds", 0.0))
    text = " ".join(str(candidate.get(k) or "") for k in ("category", "action", "pattern", "description")).lower()
    for e in reversed(existing[-15:]):
        if abs(t - float(e.get("video_time_seconds", 0.0))) > 8.0:
            continue
        other = " ".join(str(e.get(k) or "") for k in ("category", "action", "pattern", "description")).lower()
        if candidate.get("category") == e.get("category") and SequenceMatcher(None, text, other).ratio() >= 0.48:
            if float(candidate.get("confidence", 0)) > float(e.get("confidence", 0)):
                e.update(candidate)
            return True
    return False


def _normalize_synthesis(data: dict[str, Any], context: dict[str, Any], valid_ids: set[str]) -> dict[str, Any]:
    result = _empty_synthesis(context)
    if not isinstance(data, dict):
        return result
    result["warnings"] = _string_list(data.get("warnings"))
    result["non_evaluable_items"] = _string_list(data.get("non_evaluable_items"))
    result["model_game_comparison"] = _assessment_list(data.get("model_game_comparison"), valid_ids, comparison=True)

    def evidence_required(items: list[dict[str, Any]], section_name: str) -> list[dict[str, Any]]:
        kept: list[dict[str, Any]] = []
        for item in items:
            if item.get("evidence_event_ids"):
                item["evidence_level"] = "multiple" if len(item["evidence_event_ids"]) >= 2 else "single"
                kept.append(item)
                continue
            label = str(item.get("title") or item.get("criterion") or item.get("analysis") or section_name).strip()
            text = f"{label}: não há evidência de vídeo suficiente para tratar este item como conclusão observada."
            if text not in result["non_evaluable_items"]:
                result["non_evaluable_items"].append(text)
        return kept

    if context["target_type"] == "athlete":
        result["strengths"] = evidence_required(_assessment_list(data.get("strengths"), valid_ids), "ponto forte")
        result["development_points"] = evidence_required(_assessment_list(data.get("development_points"), valid_ids), "ponto a desenvolver")
        tb = data.get("tactical_behavior") if isinstance(data.get("tactical_behavior"), dict) else {}
        result["tactical_behavior"] = {
            key: evidence_required(_assessment_list(tb.get(key), valid_ids), f"comportamento tático {key}")
            for key in ("with_ball", "without_ball", "transitions", "positional_discipline")
        }
        rating = data.get("suggested_rating") if isinstance(data.get("suggested_rating"), dict) else {}
        score = rating.get("score_0_to_10")
        try:
            score = None if score is None else max(0.0, min(10.0, float(score)))
        except Exception:
            score = None
        # Highlights never receive an automatic numeric rating.
        if context.get("material_type") == "highlights":
            score = None
        result["suggested_rating"] = {
            "score_0_to_10": score,
            "confidence": _clamp(rating.get("confidence", 0.0)),
            "rationale": str(rating.get("rationale") or "").strip(),
            "human_review_required": True,
        }
    else:
        result["collective_strengths"] = evidence_required(_assessment_list(data.get("collective_strengths"), valid_ids), "força coletiva")
        result["collective_vulnerabilities"] = evidence_required(_assessment_list(data.get("collective_vulnerabilities"), valid_ids), "vulnerabilidade coletiva")
        phases = data.get("phases") if isinstance(data.get("phases"), dict) else {}
        result["phases"] = {
            key: evidence_required(_assessment_list(phases.get(key), valid_ids), f"fase {key}")
            for key in ("build_up", "progression", "final_third", "defensive_organization", "transitions", "set_pieces")
        }
        result["key_patterns"] = evidence_required(_assessment_list(data.get("key_patterns"), valid_ids), "padrão coletivo")
    return result


def _assessment_list(value: Any, valid_ids: set[str], comparison: bool = False) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    out = []
    for item in value:
        if isinstance(item, str):
            item = {"title": item, "analysis": item, "confidence": 0.0, "evidence_event_ids": []}
        if not isinstance(item, dict):
            continue
        ids = [str(x) for x in (item.get("evidence_event_ids") or []) if str(x) in valid_ids]
        confidence = _clamp(item.get("confidence", 0.0))
        if not ids:
            confidence = min(confidence, 0.49)
        obj = {
            "analysis": str(item.get("analysis") or item.get("title") or "").strip(),
            "confidence": confidence,
            "evidence_event_ids": ids,
        }
        if comparison:
            obj["criterion"] = str(item.get("criterion") or item.get("title") or "").strip()
            status = str(item.get("status") or "nao_avaliavel")
            obj["status"] = status if status in {"aderente", "parcialmente_aderente", "nao_aderente", "nao_avaliavel"} else "nao_avaliavel"
            if not ids and obj["status"] != "nao_avaliavel":
                obj["status"] = "nao_avaliavel"
        else:
            obj["title"] = str(item.get("title") or "").strip()
        if obj["analysis"] or obj.get("title") or obj.get("criterion"):
            out.append(obj)
    return out


def _empty_synthesis(context: dict[str, Any]) -> dict[str, Any]:
    base = {"model_game_comparison": [], "non_evaluable_items": [], "warnings": []}
    if context["target_type"] == "athlete":
        base.update({
            "strengths": [], "development_points": [],
            "tactical_behavior": {"with_ball": [], "without_ball": [], "transitions": [], "positional_discipline": []},
            "suggested_rating": {"score_0_to_10": None, "confidence": 0.0, "rationale": "", "human_review_required": True},
        })
    else:
        base.update({
            "collective_strengths": [], "collective_vulnerabilities": [], "key_patterns": [],
            "phases": {"build_up": [], "progression": [], "final_third": [], "defensive_organization": [], "transitions": [], "set_pieces": []},
        })
    return base


def _build_final_json(context: dict[str, Any], model: str, windows: list[dict[str, Any]],
                      events: list[dict[str, Any]], limitations: list[str], identification: dict[str, Any],
                      observed_context: dict[str, Any], synthesis: dict[str, Any], synthesis_error: str | None) -> dict[str, Any]:
    material = context["material_type"]
    chunk_seconds = DEFAULT_CHUNK_SECONDS if material == "full_match" else 10 * 60
    overlap_seconds = DEFAULT_OVERLAP_SECONDS if material == "full_match" else 10

    result = {
        "schema_version": "scout.video_analysis.v2",
        "analysis_id": str(uuid.uuid4()),
        "created_at": utc_now_iso(),
        "analysis_target": context["target_type"],
        "material_type": material,
        "source": {
            "type": context["source"]["type"],
            "reference": context["source"].get("url") or os.path.basename(context["source"].get("path") or ""),
        },
        "processing": {
            "model": model,
            "app_version": "2.3.0",
            "strategy": "static_video_windows_then_text_synthesis",
            "chunk_count": len(windows),
            "chunk_seconds": chunk_seconds,
            "overlap_seconds": overlap_seconds,
            "synthesis_status": "ok" if synthesis_error is None else "warning",
            "synthesis_error": synthesis_error,
        },
        "identification": identification,
        "observed_context": observed_context,
        "events": events,
        "limitations": limitations,
        "summary": synthesis,
        "review": {
            "status": "pending_human_review",
            "human_review_required": True,
            "confirmed": False,
        },
        "integration": dict(context.get("integration") or {}),
    }

    if material == "full_match":
        result["match"] = {
            "team": context.get("team"),
            "opponent": context.get("opponent"),
            "competition": context.get("competition"),
            "date": context.get("match_date") or None,
        }
    else:
        result["compilation_context"] = {
            "teams": context.get("teams_context") or [],
            "opponents": context.get("opponents_context") or [],
            "competitions": context.get("competitions_context") or [],
            "period": context.get("period"),
            "notes": context.get("notes"),
        }

    if context["target_type"] == "athlete":
        result["athlete"] = {
            "name": context.get("athlete_name"),
            "name_informed": context.get("athlete_name"),
            "name_observed": identification.get("observed_name"),
            "observed_aliases": identification.get("observed_aliases") or [],
            "position": context.get("position"),
            "shirt_number": context.get("shirt_number") if material == "full_match" else None,
            "team": context.get("team") if material == "full_match" else None,
            "teams_context": context.get("teams_context") or [],
        }
    else:
        result["team"] = {"name": context.get("team"), "roster_context": list(context.get("team_roster") or [])}

    if material == "highlights":
        if context["target_type"] == "athlete":
            result["sample_warning"] = (
                "A análise usa melhores momentos/amostra selecionada. O atleta pode aparecer por clubes, uniformes e camisas diferentes; "
                "o relatório descreve capacidades observadas e não deve ser interpretado como prova de consistência em jogo completo."
            )
        else:
            result["sample_warning"] = (
                "A análise usa melhores momentos/amostra selecionada da equipe, possivelmente reunindo jogos e adversários diferentes; "
                "não deve ser interpretada como prova de consistência ou frequência ao longo de partidas completas."
            )
    return result

RESULT_CODES = {
    "successful", "unsuccessful", "neutral", "inconclusive",
    "won", "lost", "completed", "incomplete", "intercepted",
    "blocked", "cleared", "retained", "lost_possession",
    "on_target", "off_target", "goal", "other",
}


def _normalize_result(event: dict[str, Any]) -> tuple[str, str]:
    code = str(event.get("result_code") or "").strip().lower()
    label = str(event.get("result_label") or "").strip()
    if code not in RESULT_CODES:
        legacy = _outcome(event.get("outcome"))
        code = {
            "positivo": "successful",
            "negativo": "unsuccessful",
            "neutro": "neutral",
            "inconclusivo": "inconclusive",
        }.get(legacy, "inconclusive")
    if not label:
        labels = {
            "successful": "ação bem-sucedida",
            "unsuccessful": "ação malsucedida",
            "neutral": "resultado neutro",
            "inconclusive": "resultado inconclusivo",
            "won": "duelo vencido",
            "lost": "duelo perdido",
            "completed": "ação completada",
            "incomplete": "ação não completada",
            "intercepted": "interceptação",
            "blocked": "bloqueio",
            "cleared": "corte/afastamento",
            "retained": "posse mantida",
            "lost_possession": "perda de posse",
            "on_target": "finalização no alvo",
            "off_target": "finalização fora do alvo",
            "goal": "gol",
            "other": "outro resultado",
        }
        label = labels.get(code, "resultado inconclusivo")
    return code, label


def _outcome(value: Any) -> str:
    text = str(value or "inconclusivo").lower().strip()
    return text if text in {"positivo", "negativo", "neutro", "inconclusivo"} else "inconclusivo"


def _optional_text(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None


def _clamp(value: Any) -> float:
    try:
        return round(max(0.0, min(1.0, float(value))), 3)
    except Exception:
        return 0.0


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(x).strip() for x in value if str(x).strip()]
