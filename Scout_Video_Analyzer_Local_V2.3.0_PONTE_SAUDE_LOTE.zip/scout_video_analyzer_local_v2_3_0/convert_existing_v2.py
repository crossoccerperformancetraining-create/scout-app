from __future__ import annotations

from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

from audit_contract import build_analysis_v3
from report_pdf import generate_report_pdf
from utils import read_json, write_json

APP_TITLE = "Scout Video Analyzer Local V2.3.0"


def main() -> int:
    root = tk.Tk()
    root.withdraw()
    path = filedialog.askopenfilename(
        title="Selecione scout_analysis_v2.json",
        filetypes=[("Scout Analysis V2", "scout_analysis_v2.json"), ("JSON", "*.json")],
    )
    if not path:
        return 0
    src = Path(path)
    try:
        v2 = read_json(src)
        if v2.get("schema_version") != "scout.video_analysis.v2":
            raise ValueError("O arquivo selecionado não usa o schema scout.video_analysis.v2.")
        v3 = build_analysis_v3(v2)
        v3_path = src.parent / "scout_analysis_v3.json"
        pdf_path = src.parent / "scout_report_draft.pdf"
        write_json(v3_path, v3)
        generate_report_pdf(v3, pdf_path)
        messagebox.showinfo(
            APP_TITLE,
            "Conversão concluída.\n\n"
            f"JSON universal: {v3_path}\n\n"
            f"PDF preliminar: {pdf_path}",
        )
        return 0
    except Exception as exc:
        messagebox.showerror(APP_TITLE, f"Não foi possível converter a análise:\n\n{type(exc).__name__}: {exc}")
        return 1
    finally:
        try:
            root.destroy()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
