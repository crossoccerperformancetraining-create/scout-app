from __future__ import annotations

from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    KeepTogether,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)

NAVY = colors.HexColor("#0B1628")
BLUE = colors.HexColor("#17345A")
LIGHT = colors.HexColor("#EDF3FA")
MID = colors.HexColor("#D5E1EF")
TEXT = colors.HexColor("#182230")
MUTED = colors.HexColor("#5F6B78")


def _text(value: Any, fallback: str = "-") -> str:
    s = str(value or "").strip()
    return s or fallback


def _pct(value: Any) -> str:
    try:
        return f"{float(value) * 100:.0f}%"
    except Exception:
        return "-"


def _page(canvas, doc):
    canvas.saveState()
    width, height = A4
    canvas.setFillColor(NAVY)
    canvas.rect(0, height - 20 * mm, width, 20 * mm, fill=1, stroke=0)
    canvas.setFillColor(colors.white)
    canvas.setFont("Helvetica-Bold", 12)
    canvas.drawString(16 * mm, height - 12.5 * mm, "AUDIT SCOUT - VIDEO INTELLIGENCE")
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(MUTED)
    canvas.drawRightString(width - 16 * mm, 9 * mm, f"Pagina {doc.page}")
    canvas.restoreState()


def generate_report_pdf(v3: dict[str, Any], output_path: str | Path) -> Path:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    width, height = A4
    frame = Frame(16 * mm, 16 * mm, width - 32 * mm, height - 42 * mm, id="normal")
    doc = BaseDocTemplate(
        str(output),
        pagesize=A4,
        rightMargin=16 * mm,
        leftMargin=16 * mm,
        topMargin=26 * mm,
        bottomMargin=16 * mm,
        title=(v3.get("report") or {}).get("title") or "Scout Report",
        author="Audit Scout / Scout Video Analyzer",
    )
    doc.addPageTemplates(PageTemplate(id="main", frames=[frame], onPage=_page))

    styles = getSampleStyleSheet()
    title = ParagraphStyle("TitleScout", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=20, leading=24, textColor=NAVY, alignment=TA_LEFT, spaceAfter=5 * mm)
    h1 = ParagraphStyle("H1Scout", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=13, leading=16, textColor=NAVY, spaceBefore=5 * mm, spaceAfter=2.5 * mm)
    body = ParagraphStyle("BodyScout", parent=styles["BodyText"], fontName="Helvetica", fontSize=9.4, leading=13, textColor=TEXT, spaceAfter=2 * mm)
    small = ParagraphStyle("SmallScout", parent=body, fontSize=8.3, leading=11, textColor=MUTED)
    center = ParagraphStyle("CenterScout", parent=small, alignment=TA_CENTER, textColor=colors.HexColor("#8B2D2D"), fontName="Helvetica-Bold")

    story = []
    report_meta = v3.get("report") or {}
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(_text(report_meta.get("title"), "Relatorio Scout"), title))
    story.append(Paragraph("RASCUNHO - REVISAO HUMANA PENDENTE", center))
    story.append(Spacer(1, 3 * mm))

    subject = v3.get("subject") or {}
    material = v3.get("material") or {}
    identification = v3.get("identification") or {}
    if subject.get("type") == "athlete":
        athlete = subject.get("athlete") or {}
        name = athlete.get("name_informed") or athlete.get("name_observed")
        subject_rows = [
            ["Atleta", _text(name), "Posicao", _text(athlete.get("position"))],
            ["Nome observado", _text(athlete.get("name_observed")), "Confianca de identificacao", _pct(identification.get("confidence_mean"))],
            ["Material", "Melhores momentos" if material.get("type") == "highlights" else "Jogo completo", "Fonte", _text((material.get("source") or {}).get("type"))],
        ]
    else:
        team = subject.get("team") or {}
        subject_rows = [
            ["Equipe", _text(team.get("name_informed")), "Material", "Melhores momentos" if material.get("type") == "highlights" else "Jogo completo"],
            ["Confianca de identificacao", _pct(identification.get("confidence_mean")), "Fonte", _text((material.get("source") or {}).get("type"))],
        ]
    info_table = Table(subject_rows, colWidths=[34 * mm, 55 * mm, 43 * mm, 46 * mm])
    info_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), LIGHT), ("BACKGROUND", (2, 0), (2, -1), LIGHT),
        ("TEXTCOLOR", (0, 0), (-1, -1), TEXT),
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"), ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("GRID", (0, 0), (-1, -1), 0.35, MID),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(info_table)

    warning = material.get("sample_warning") or (v3.get("ai_assessment") or {}).get("sample_warning")
    if warning:
        story.append(Spacer(1, 3 * mm))
        warn_table = Table([[Paragraph(f"<b>Limite metodologico:</b> {_text(warning)}", small)]], colWidths=[178 * mm])
        warn_table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF5DD")), ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#D6A326")), ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        story.append(warn_table)

    ai = v3.get("ai_assessment") or {}
    story.append(Paragraph("1. Leitura assistida por IA", h1))
    _append_assessments(story, "Pontos fortes observados", ai.get("strengths") or ai.get("collective_strengths"), body, small)
    _append_assessments(story, "Pontos a desenvolver observados", ai.get("development_points") or ai.get("collective_vulnerabilities"), body, small)

    non_eval = ai.get("non_evaluable_items") or []
    if non_eval:
        story.append(Paragraph("Itens nao avaliaveis", h1))
        for item in non_eval:
            story.append(Paragraph(f"- {_text(item)}", body))

    rating = ai.get("suggested_rating") if isinstance(ai.get("suggested_rating"), dict) else None
    if rating:
        score = rating.get("score_0_to_10")
        score_text = "Nao atribuida" if score is None else f"{float(score):.1f}/10"
        story.append(Paragraph("Nota sugerida pela IA", h1))
        story.append(Paragraph(f"<b>{score_text}</b> - {_text(rating.get('rationale'))}", body))

    story.append(Paragraph("2. Evidencias de video", h1))
    evidences = v3.get("evidence") or []
    rows = [["Tempo", "Acao/padrao", "Resultado", "Conf. ID", "Conf. acao"]]
    for e in evidences[:40]:
        action = e.get("action") or e.get("pattern") or e.get("description")
        conf = e.get("confidence") or {}
        result = e.get("result") or {}
        rows.append([
            _text(e.get("video_timestamp")),
            Paragraph(_text(action), small),
            Paragraph(_text(result.get("label")), small),
            _pct(conf.get("identification")),
            _pct(conf.get("action")),
        ])
    if len(rows) == 1:
        rows.append(["-", "Nenhuma evidencia estruturada", "-", "-", "-"])
    evidence_table = Table(rows, repeatRows=1, colWidths=[20 * mm, 72 * mm, 38 * mm, 24 * mm, 24 * mm])
    evidence_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), BLUE), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 7.8), ("GRID", (0, 0), (-1, -1), 0.35, MID),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(evidence_table)

    story.append(Paragraph("3. Avaliacao humana / Scout", h1))
    human = v3.get("human_assessment") or {}
    if human.get("status") in (None, "not_started"):
        story.append(Paragraph("Ainda nao preenchida. O profissional deve confirmar, ajustar ou rejeitar as evidencias e conclusoes antes da emissao do relatorio oficial.", body))
    else:
        story.append(Paragraph(_text(human.get("notes"), "Avaliacao humana registrada."), body))

    story.append(Paragraph("4. Conclusao final", h1))
    final = v3.get("final_assessment") or {}
    if final.get("status") == "pending_review":
        story.append(Paragraph("Pendente de revisao humana. Este documento nao substitui a decisao do scout, analista ou treinador responsavel.", body))
    else:
        story.append(Paragraph(_text(final.get("summary")), body))

    story.append(Paragraph("5. Auditoria", h1))
    audit = v3.get("audit") or {}
    audit_rows = [
        ["Schema", _text(v3.get("schema_version"))],
        ["Modelo IA", _text(audit.get("model"))],
        ["Gerado por", _text(audit.get("generated_by"))],
        ["Status de revisao", _text((v3.get("review") or {}).get("status"))],
    ]
    audit_table = Table(audit_rows, colWidths=[42 * mm, 136 * mm])
    audit_table.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, -1), LIGHT), ("GRID", (0, 0), (-1, -1), 0.35, MID), ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"), ("FONTNAME", (1, 0), (1, -1), "Helvetica"), ("FONTSIZE", (0, 0), (-1, -1), 8), ("LEFTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    story.append(audit_table)

    doc.build(story)
    return output


def _append_assessments(story, heading: str, items: Any, body, small) -> None:
    if not isinstance(items, list) or not items:
        return
    story.append(Paragraph(heading, ParagraphStyle("sub", parent=body, fontName="Helvetica-Bold", fontSize=10.2, textColor=NAVY, spaceBefore=2 * mm, spaceAfter=1 * mm)))
    for item in items:
        if not isinstance(item, dict):
            continue
        title = _text(item.get("title") or item.get("criterion"), "Observacao")
        analysis = _text(item.get("analysis"))
        ids = ", ".join(str(x) for x in (item.get("evidence_event_ids") or [])) or "sem evidencia vinculada"
        conf = _pct(item.get("confidence"))
        story.append(KeepTogether([
            Paragraph(f"<b>{title}</b> ({conf})", body),
            Paragraph(analysis, body),
            Paragraph(f"Evidencias: {ids}", small),
        ]))
