@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Diagnostico Scout Video Analyzer V2.3.0
set "SCOUT_HOME=%LOCALAPPDATA%\ScoutVideoAnalyzerLocalV2"
set "VENV=%SCOUT_HOME%\venv"

echo ============================================================
echo SCOUT VIDEO ANALYZER V2.3.0 - DIAGNOSTICO
echo ============================================================
echo Pasta do programa: %CD%
echo Ambiente local: %VENV%
echo.

if not exist "%VENV%\Scripts\python.exe" (
  echo STATUS: ambiente Python AUSENTE ou incompleto.
  echo SOLUCAO: execute START_SCOUT_ANALYZER_V2.cmd; a V2.3.0 recria o ambiente automaticamente.
  goto :logs
)

echo STATUS: ambiente Python encontrado.
echo Versao do Python:
"%VENV%\Scripts\python.exe" --version

echo.
echo Testando componentes da V2.3.0...
"%VENV%\Scripts\python.exe" -c "import tkinter; print('tkinter: OK'); import keyring; print('keyring: OK'); from google import genai; print('google-genai: OK'); import reportlab; import app, pipeline, prompts, gemini_client, audit_contract, report_pdf, local_bridge; print('Scout V2.3.0: OK')"
echo Codigo do teste: %ERRORLEVEL%

echo.
echo Testando estrutura local V2.3.0...
"%VENV%\Scripts\python.exe" "%~dp0TESTE_ESTRUTURA.py"
echo Codigo do teste estrutural: %ERRORLEVEL%

:logs
echo.
echo ---------------- start_v230.log ----------
if exist "%SCOUT_HOME%\logs\start_v230.log" type "%SCOUT_HOME%\logs\start_v230.log"
echo.
echo ---------------- setup.log ---------------
if exist "%SCOUT_HOME%\logs\setup.log" powershell -NoProfile -Command "Get-Content -LiteralPath '%SCOUT_HOME%\logs\setup.log' -Tail 80"
echo.
echo ---------------- startup.log -------------
if exist "%SCOUT_HOME%\logs\startup.log" powershell -NoProfile -Command "Get-Content -LiteralPath '%SCOUT_HOME%\logs\startup.log' -Tail 80"
echo.
echo ---------------- analysis.log ------------
if exist "%SCOUT_HOME%\logs\analysis.log" powershell -NoProfile -Command "Get-Content -LiteralPath '%SCOUT_HOME%\logs\analysis.log' -Tail 80"
echo.
echo ============================================================
echo Se houver erro, envie uma foto desta janela ou copie o texto.
echo ============================================================
pause
endlocal
