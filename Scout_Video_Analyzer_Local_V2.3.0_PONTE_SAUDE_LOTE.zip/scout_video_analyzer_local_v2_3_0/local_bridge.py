from __future__ import annotations

import json
import os
import secrets
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

BRIDGE_VERSION = "1.0"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765
BASE_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "ScoutVideoAnalyzerLocalV2" / "bridge"
JOBS_DIR = BASE_DIR / "jobs"
RESULTS_DIR = BASE_DIR / "results"
STATES_DIR = BASE_DIR / "states"
TOKEN_FILE = BASE_DIR / "bridge_token.txt"
for d in (BASE_DIR, JOBS_DIR, RESULTS_DIR, STATES_DIR):
    d.mkdir(parents=True, exist_ok=True)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def get_or_create_token() -> str:
    try:
        token = TOKEN_FILE.read_text(encoding="utf-8").strip()
        if len(token) >= 20:
            return token
    except Exception:
        pass
    token = secrets.token_urlsafe(24)
    TOKEN_FILE.write_text(token, encoding="utf-8")
    return token


def bridge_dirs() -> dict[str, str]:
    return {
        "base": str(BASE_DIR),
        "jobs": str(JOBS_DIR),
        "results": str(RESULTS_DIR),
        "states": str(STATES_DIR),
    }


def _safe_id(value: Any) -> str:
    text = str(value or "").strip()
    text = "".join(ch for ch in text if ch.isalnum() or ch in "-_.")
    return text[:120] or f"JOB-{int(datetime.now().timestamp() * 1000)}"


def _write_json(path: Path, obj: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def save_job(job: dict[str, Any]) -> str:
    job_id = _safe_id(job.get("job_id"))
    job = dict(job)
    job["job_id"] = job_id
    job.setdefault("received_at", _utc_now())
    _write_json(JOBS_DIR / f"{job_id}.json", job)
    mark_state(job_id, "queued", "Tarefa recebida do Scout Intelligence.")
    return job_id


def load_job(job_id: str) -> dict[str, Any] | None:
    path = JOBS_DIR / f"{_safe_id(job_id)}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def list_jobs(statuses: set[str] | None = None) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for path in sorted(JOBS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            job = json.loads(path.read_text(encoding="utf-8"))
            job_id = _safe_id(job.get("job_id") or path.stem)
            state = read_state(job_id)
            if statuses and state.get("status") not in statuses:
                continue
            items.append({"job_id": job_id, "job": job, "state": state})
        except Exception:
            continue
    return items


def next_queued_job() -> dict[str, Any] | None:
    items = list_jobs({"queued"})
    if not items:
        return None
    # Oldest queued first, to preserve the Scout's work order.
    return sorted(items, key=lambda x: str(x["job"].get("received_at") or ""))[0]


def mark_state(job_id: str, status: str, message: str = "", **extra: Any) -> dict[str, Any]:
    job_id = _safe_id(job_id)
    current = read_state(job_id)
    payload = {
        **current,
        "job_id": job_id,
        "status": str(status),
        "message": str(message or ""),
        "updated_at": _utc_now(),
        **extra,
    }
    payload.setdefault("created_at", _utc_now())
    _write_json(STATES_DIR / f"{job_id}.json", payload)
    return payload


def read_state(job_id: str) -> dict[str, Any]:
    path = STATES_DIR / f"{_safe_id(job_id)}.json"
    if not path.exists():
        return {"job_id": _safe_id(job_id), "status": "queued", "message": ""}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"job_id": _safe_id(job_id), "status": "unknown", "message": "Estado ilegível."}


def publish_result(job_id: str, result: dict[str, Any], *, project_dir: str | None = None) -> Path:
    job_id = _safe_id(job_id)
    out = RESULTS_DIR / f"{job_id}.json"
    payload = dict(result)
    payload.setdefault("bridge", {})
    if isinstance(payload["bridge"], dict):
        payload["bridge"].update({"job_id": job_id, "published_at": _utc_now(), "bridge_version": BRIDGE_VERSION})
    _write_json(out, payload)
    mark_state(job_id, "completed", "Resultado V3 pronto para o Scout.", project_dir=project_dir, result_file=str(out))
    return out


def load_result(job_id: str) -> dict[str, Any] | None:
    path = RESULTS_DIR / f"{_safe_id(job_id)}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


class _BridgeHandler(BaseHTTPRequestHandler):
    server_version = "ScoutAnalyzerBridge/1.0"

    def log_message(self, _fmt: str, *_args: Any) -> None:
        return

    def _cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,X-Scout-Bridge-Token")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Cache-Control", "no-store")

    def _json(self, status: int, payload: Any) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _authorized(self) -> bool:
        expected = getattr(self.server, "bridge_token", "")
        supplied = self.headers.get("X-Scout-Bridge-Token", "")
        return bool(expected) and secrets.compare_digest(str(expected), str(supplied))

    def _need_auth(self) -> bool:
        if self._authorized():
            return False
        self._json(401, {"ok": False, "error": "bridge_token_required"})
        return True

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        if path in {"/", "/health"}:
            queued = len(list_jobs({"queued"}))
            running = len(list_jobs({"loaded", "running"}))
            completed = len(list_jobs({"completed"}))
            self._json(200, {
                "ok": True,
                "service": "Scout Video Analyzer Local Bridge",
                "bridge_version": BRIDGE_VERSION,
                "analyzer_version": getattr(self.server, "analyzer_version", "unknown"),
                "host": DEFAULT_HOST,
                "port": getattr(self.server, "server_port", DEFAULT_PORT),
                "token_required": True,
                "queued_jobs": queued,
                "active_jobs": running,
                "ready_results": completed,
            })
            return
        if self._need_auth():
            return
        if path == "/jobs":
            self._json(200, {"ok": True, "jobs": [{"job_id": x["job_id"], "state": x["state"]} for x in list_jobs()]})
            return
        if path.startswith("/status/"):
            job_id = path.split("/", 2)[2]
            self._json(200, {"ok": True, "state": read_state(job_id)})
            return
        if path.startswith("/results/"):
            job_id = path.split("/", 2)[2]
            result = load_result(job_id)
            if result is None:
                self._json(404, {"ok": False, "error": "result_not_ready", "state": read_state(job_id)})
            else:
                self._json(200, {"ok": True, "job_id": _safe_id(job_id), "result": result})
            return
        self._json(404, {"ok": False, "error": "not_found"})

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        if self._need_auth():
            return
        try:
            size = int(self.headers.get("Content-Length", "0") or "0")
            if size <= 0 or size > 2_000_000:
                raise ValueError("body_size_invalid")
            raw = json.loads(self.rfile.read(size).decode("utf-8"))
        except Exception as exc:
            self._json(400, {"ok": False, "error": f"invalid_json: {exc}"})
            return
        if path == "/jobs":
            job = raw.get("job") if isinstance(raw, dict) and isinstance(raw.get("job"), dict) else raw
            if not isinstance(job, dict) or not str(job.get("schema_version") or "").startswith("scout.analyzer.job"):
                self._json(400, {"ok": False, "error": "invalid_scout_job"})
                return
            job_id = save_job(job)
            self._json(201, {"ok": True, "job_id": job_id, "state": read_state(job_id)})
            return
        if path.startswith("/ack/"):
            job_id = path.split("/", 2)[2]
            state = mark_state(job_id, "acknowledged", "Resultado recebido pelo Scout.")
            self._json(200, {"ok": True, "state": state})
            return
        self._json(404, {"ok": False, "error": "not_found"})


def start_bridge_server(*, analyzer_version: str, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT):
    token = get_or_create_token()
    server = ThreadingHTTPServer((host, int(port)), _BridgeHandler)
    server.bridge_token = token  # type: ignore[attr-defined]
    server.analyzer_version = analyzer_version  # type: ignore[attr-defined]
    thread = threading.Thread(target=server.serve_forever, daemon=True, name="ScoutAnalyzerLocalBridge")
    thread.start()
    return server, thread, token
